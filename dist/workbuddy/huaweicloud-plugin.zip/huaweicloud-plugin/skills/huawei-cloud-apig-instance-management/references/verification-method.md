# Verification Method

Each `huawei_*` action must be verified after execution. Read-only actions are
verified directly from the command output; mutating actions require a read-back
(回读) step that confirms the change.

## 1. Query actions (R3)

| Action                                     | Verification                                                                                                                                                                                                             |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `huawei_list_apig_instances`               | JSON response contains `instances[]` with `id`, `status`, `eip_address`                                                                                                                                                  |
| `huawei_get_apig_instance`                 | Response contains exactly the requested `--instance_id`, `status != ""`. **Empty result (`total: 0`) means the instance does NOT exist** — report "实例不存在,请确认 instance_id", do not treat it as a successful query |
| `huawei_list_apig_api_groups`              | Response contains `groups[]` with `id`, `name`, `sl_domain`                                                                                                                                                              |
| `huawei_list_apig_apis`                    | Response contains `apis[]` with `id`, `name`, `req_uri`, `auth_type`                                                                                                                                                     |
| `huawei_list_apig_throttling_policies`     | Response contains `throttles[]` with `id`, `name`, `api_call_limits`                                                                                                                                                     |
| `huawei_list_apig_signature_keys`          | Response contains `signs[]` with `id`, `name`, `sign_key`, `sign_type`                                                                                                                                                   |
| `huawei_list_apig_access_control_policies` | Response contains `acls[]` with `id`, `acl_name`, `acl_type`, `acl_value`, `entity_type`                                                                                                                                 |

```bash
# Example verification (all commands wrapped per the mandatory reporting rule)
skill-quality-cli run --skill-name huawei-cloud-apig-instance-management -- hcloud APIG ListInstancesV2 --cli-region={region} --cli-output=json | jq '.instances[] | {id, name, status, eip_address}'
```

## 2. Analyze actions (R3)

| Action                              | Verification                                                                                                                                                                                                    |
| ----------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `huawei_analyze_apig_public_access` | Conclusion derived from `eip_address` (public) vs null (internal) vs `sl_domain` (internal-only); the report must state which address is safe for public use                                                    |
| `huawei_analyze_apig_publish_chain` | Chain walk completes at each hop: instance -> group -> API -> `publish_id`; missing hop is reported explicitly                                                                                                  |
| `huawei_analyze_apig_policy_effect` | For the target `sign_id`/`acl_id`/`throttle_id`, the report states whether ≥ 1 bound API is published (`publish_id` non-empty): in effect / exists-but-unbound / bound-but-unpublished — never a generic answer |

## 3. Manage actions (R2 — preview + confirm; then read-back)

| Action                                     | Read-back verification                                                                                                                                                                                                                                                                           |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `huawei_create_apig_instance`              | Poll `ListInstancesV2` until `status == "Running"` (5-15 min). Do NOT stop at `CreateSuccess`.                                                                                                                                                                                                   |
| `huawei_add_apig_ingress_eip`              | Confirm via the `AddIngressEipV2` response/task acceptance, a retry returning `APIC.7711` ("Public inbound access is enabled"), or the EIP list in the APIG console. **Do NOT rely on `ListInstancesV2` `eip_address` as the sole evidence** — it can remain `null` for 8+ minutes after success |
| `huawei_create_apig_api_group`             | `ListApiGroupsV2 --instance_id` contains the new group (match by name/id); capture `sl_domain`                                                                                                                                                                                                   |
| `huawei_create_apig_api`                   | `ListApisV2 --instance_id --group_id` contains the new API. **Known limitation:** with KooCLI 7.2.12 an HTTP backend (`--backend_type=HTTP`) fails with APIG.2011 — use `MOCK`/`FUNCTION` backend or the console for HTTP backends                                                               |
| `huawei_update_apig_api`                   | `ListApisV2` shows the updated fields (path, auth mode, etc.)                                                                                                                                                                                                                                    |
| `huawei_publish_apig_api`                  | `ListApisV2` for the API shows a non-null `publish_id` (published). **`--env_id` must be the real environment ID** obtained from `hcloud APIG ListEnvironmentsV2 --cli-region={region} --instance_id={instance_id}` — the name `RELEASE` is rejected with APIG.3003                              |
| `huawei_create_apig_throttling_policy`     | `ListRequestThrottlingPolicyV2 --instance_id` contains the new policy                                                                                                                                                                                                                            |
| `huawei_create_apig_signature_key`         | `ListSignatureKeysV2 --instance_id` contains the new key (match by name). Note `sign_secret` is only returned at create time; the list shows the key but not the raw secret                                                                                                                      |
| `huawei_create_apig_access_control_policy` | `ListAclStrategiesV2 --instance_id` contains the new policy (match by `acl_name`; check `acl_type`/`entity_type`/`acl_value` were honored)                                                                                                                                                       |

## 4. Delete actions (R1 — explicit confirm; then confirm removal)

| Action                                     | Verification                                                                                                                                                                                                                                 |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `huawei_delete_apig_instance`              | `ListInstancesV2 --instance_id` returns empty / instance gone (deletion is async; poll until absent)                                                                                                                                         |
| `huawei_delete_apig_api`                   | `ListApisV2 --instance_id --group_id` no longer contains the API id                                                                                                                                                                          |
| `huawei_delete_apig_api_group`             | `ListApiGroupsV2 --instance_id` no longer contains the group id. **Group must be empty first**: delete every API in it via `huawei_delete_apig_api` (`DeleteApiV2`), otherwise APIG rejects the deletion (`APIG.3415` — group contains APIs) |
| `huawei_delete_apig_signature_key`         | `ListSignatureKeysV2 --instance_id --id` returns empty for the key; confirm its bindings were removed too                                                                                                                                    |
| `huawei_delete_apig_access_control_policy` | `ListAclStrategiesV2 --instance_id --id` returns empty for the policy. **Policy must have no API bindings**, otherwise `DeleteAclV2` errors — unbind APIs first and retry                                                                    |

## 5. General rules

1. Always pass `--cli-output=json` when the result is consumed programmatically (e.g. with `jq`).
2. Before running any operation, confirm parameter names with `hcloud APIG <Operation> --help`.
3. Mutating commands: preview the full command, get user confirmation, execute, then read back. Never skip the read-back.
4. If a read-back fails, return the error and do not claim success.

## 6. Quality reporting (CLI) verification

```bash
# 6.1 CLI install (idempotent) + PATH export
export PATH="$HOME/.local/bin:$PATH"
bash scripts/ensure_cli.sh
command -v skill-quality-cli   # or ~/.local/bin/skill-quality-cli

# 6.2 Wrapper mode: every hcloud command is wrapped (SKILL.md mandatory rule)
skill-quality-cli run --skill-name huawei-cloud-apig-instance-management -- hcloud APIG ListInstancesV2 --cli-region={region} --limit=1

# 6.3 E2E real delivery through the bundled carrier (must print [quality-report] OK trace_id=...)
printf '{"session_id":"verify-apig","trigger_type":"workflow"}' > /tmp/qcfg.json
SKILL_QUALITY_REPORT_VERBOSE=1 python3 scripts/cli/cli_entry.py --no-auto-upgrade \
  report --skill-name huawei-cloud-apig-instance-management --status success --json /tmp/qcfg.json 2>&1 | tail -1
```

Expected: step 6.3 prints `[quality-report] OK trace_id=<id>` (HTTP 200 from the quality endpoint);
step 6.2 completes with its normal output/exit code unchanged if a live account is available.
