<!-- generated from src/packs/huaweicloud-cli/skills/huawei-cloud-dew-key-management - do not edit -->

# KMS Usage Guide

KMS (Key Management Service) manages customer master keys (CMK). All management actions
are gated (R2/R1 preview + confirm). **Never decrypt inside the agent context.**

## Action reference

| huawei_* action                          | CLI command                                                                 | Level                    |
| ---------------------------------------- | --------------------------------------------------------------------------- | ------------------------ |
| `huawei_list_kms_keys`                   | `hcloud KMS ListKeys --cli-region={region}`                                 | R3 auto                  |
| `huawei_create_kms_key`                  | `hcloud KMS CreateKey --cli-region={region} --key_alias={alias}`            | R2 confirm               |
| `huawei_delete_kms_key`                  | `hcloud KMS DeleteKey --cli-region={region} --key_id={id} --pending_days=7` | R1 confirm, irreversible |
| `huawei_analyze_dew_rotation` (KMS side) | `hcloud KMS ShowKeyRotationStatus --cli-region={region} --key_id={id}`      | R3 auto                  |

## Examples

List keys (metadata only):

```bash
hcloud KMS ListKeys --cli-region=cn-north-4 --key_state=2 --limit=50
```

Create a symmetric encryption key (R2 — confirm first):

```bash
hcloud KMS CreateKey --cli-region=cn-north-4 --key_alias=app-encryption-key \
  --key_description="Application data encryption" --key_spec=AES_256
```

Show key rotation status:

```bash
hcloud KMS ShowKeyRotationStatus --cli-region=cn-north-4 --key_id={key_id}
```

Enable key rotation (not a huawei_* action — for reference):

```bash
hcloud KMS EnableKeyRotation --cli-region=cn-north-4 --key_id={key_id}
```

## Key deletion — IRREVERSIBLE

```bash
hcloud KMS DeleteKey --cli-region=cn-north-4 --key_id={key_id} --pending_days=7
```

- Schedules deletion after `--pending_days` (required, 7~1096 — choose 7 for the shortest recovery-friendly window).
- Cancellable during the window: `hcloud KMS CancelKeyDeletion --cli-region=cn-north-4 --key_id={id}`
- **After the window passes, the key is permanently deleted and data encrypted with it is
  UNRECOVERABLE.** Always show this warning and require explicit confirmation (R1).

> Note: `hcloud KMS DeleteKey` maps to the _schedule-key-deletion_ API
> (endpoint `POST /v1.0/{project_id}/kms/schedule-key-deletion`).

## Encrypt / decrypt policy

| Operation                                   | Policy                                                                                                                                                                                 |
| ------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `hcloud KMS ListKeys`                       | **ALLOWED** (metadata only)                                                                                                                                                            |
| `hcloud KMS ListKeyDetail`                  | **ALLOWED** (metadata only)                                                                                                                                                            |
| `hcloud KMS ShowKeyRotationStatus`          | **ALLOWED** (metadata only)                                                                                                                                                            |
| `hcloud KMS CreateKey`                      | ALLOWED (R2 preview + confirm)                                                                                                                                                         |
| `hcloud KMS DeleteKey` (schedule deletion)  | ALLOWED (R1 preview + confirm, irreversible warning)                                                                                                                                   |
| `hcloud KMS EncryptData` / `EncryptDatakey` | NOT gated (classifies unknown_read) — takes `--plain_text` on argv (the plaintext enters shell history / `ps aux`); never run in agent context; encrypt inside the application runtime |
| `hcloud KMS DecryptData` / `DecryptDatakey` | **HOOK-BLOCKED** (v2 secret-read vocabulary) — decrypt inside the application runtime, never in agent context                                                                          |
| `hcloud KMS CreateDatakey`                  | Approval-gated write whose response carries the plaintext datakey — doctrine: do NOT run; use `CreateDatakeyWithoutPlaintext` (ciphertext only) or envelope encryption                 |

Endpoint (verified): `POST /v1.0/{project_id}/kms/list-keys`,
`POST /v1.0/{project_id}/kms/create-key`,
`POST /v1.0/{project_id}/kms/schedule-key-deletion`,
`POST /v1.0/{project_id}/kms/get-key-rotation-status`.
