<!-- generated from src/packs/obs/skills/huawei-obs - do not edit -->

# OBS Static Website Deployment

## Workflow

```
1. Build project     → npm run build / yarn build
2. Create OBS bucket  → hcloud OBS mb obs://<bucket> -location=<region>
3. Bulk upload        → hcloud OBS cp <build-dir>/ obs://<bucket>/ -r -f -flat -acl=public-read
4. Set bucket ACL     → hcloud OBS chattri obs://<bucket> -acl=public-read
5. Set object ACLs    → hcloud OBS chattri obs://<bucket>/ -r -f -acl=public-read
6. Configure website  → huaweicloud_obs_set_website_config tool (recommended; 7.3.12+ also ships `hcloud OBS website -method=put -localfile=<xml>`, XML-file based)
7. Verify             → GET with headers: curl -s -D - -o /dev/null http://<bucket>.obs-website.<region>.myhuaweicloud.com (see common-pitfalls.md #899 — a bare 200 can still download instead of render)
```

## Step-by-Step (Vue/Vite Example)

```bash
# 1. Build
npm run build                  # outputs to dist/

# 2. Create bucket in target region
hcloud OBS mb obs://my-static-site -location=cn-north-4

# 3. Upload entire build directory (recursive, force, flatten, public ACL)
hcloud OBS cp dist/ obs://my-static-site/ -r -f -flat -acl=public-read

# 4. Set bucket ACL (required for static website access)
hcloud OBS chattri obs://my-static-site -acl=public-read

# 5. Set object ACLs recursively (objects don't inherit bucket ACL automatically)
hcloud OBS chattri obs://my-static-site/ -r -f -acl=public-read

# 5. Configure static website hosting — MCP tool (recommended, no XML juggling):
# action=set, bucket=<bucket>, region=<region>, indexDocument=index.html, errorDocument=404.html
# KooCLI 7.3.12+ alternative (XML-file based):
#   hcloud OBS website obs://my-static-site -method=put -localfile=website.xml
#   (website.xml carries the WebsiteConfiguration; 7.2.x has no such command)
# Or use Huawei Cloud Console:
#   Console → OBS → Bucket → Basic Settings → Static Website Hosting

# 6. Verify
curl -s -D - -o /dev/null http://my-static-site.obs-website.cn-north-4.myhuaweicloud.com   # GET with headers (#899): a bare 200 can download instead of render
```

## Key Gotchas

- **Build output dir varies**: `dist/` (Vite), `build/` (CRA), `out/` (Next.js). Check `package.json` scripts.
- **Bucket name must be DNS-compliant**: lowercase, numbers, hyphens only. No underscores or uppercase.
- **Region matters**: Website endpoint depends on bucket region. `obs-website.<region>.myhuaweicloud.com`.
- **Index.html routing**: For SPA apps (Vue Router, React Router), set `ErrorDocument` to `index.html` as well.
- **Cache invalidation**: New uploads don't clear CDN cache. Add `?v=<timestamp>` to asset references or use OBS versioning.
- **Always use `-f`**: Without `-f`, obsutil prompts "Please input (y/n)" on large uploads — Agent hangs (TIMEOUT).
- **Use `-flat` for root files**: Without `-flat`, `dist/` becomes `bucket/dist/` prefix. Static sites need files at bucket root.
- **Objects don't inherit bucket ACL**: Setting bucket to public-read does NOT make individual objects public. You must also set object-level ACL with `chattri obs://<bucket>/ -r -f -acl=public-read` or use `-acl=public-read` during upload.
- **`mb` may return a non-zero exit code even on success**: `hcloud OBS mb` occasionally exits with code 6 (or other non-zero) while the bucket is actually created — the output still contains a request id and subsequent `cp`/`chattri` succeed. Judge success by the response text (request id) and confirm with `hcloud OBS ls` / `stat obs://<bucket>`, NOT the exit code alone. `mb` is idempotent, so re-issuing the same bucket name is harmless.
- **Website endpoint is eventually consistent (~1 min)**: after `PUT /?website` returns 200, the website endpoint (`http://<bucket>.obs-website.<region>.myhuaweicloud.com`) may return 404 `NoSuchWebsiteConfiguration` for up to ~1 minute. This is propagation delay, NOT a configuration failure. Verify immediately via the object URL (`https://<bucket>.obs.<region>.myhuaweicloud.com/index.html`, works before the website endpoint), then poll the website endpoint with a short backoff until it returns 200 before reporting success. **A 200 is necessary but NOT sufficient (#899)**: on post-2022 buckets the GET is force-injected `Content-Disposition: attachment` — the page downloads instead of rendering. Browser-level verification (or `curl -s -D -` + header inspection) is the only success criterion; see common-pitfalls.md.
