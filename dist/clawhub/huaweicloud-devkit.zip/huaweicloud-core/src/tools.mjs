import { readFileSync, readdirSync, existsSync, writeFileSync, rmSync, mkdirSync } from 'node:fs';
import { join, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir, tmpdir } from 'node:os';
import { spawnSync, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createHmac, createHash } from 'node:crypto';

import { evaluateArtifacts, evaluateCommandRisk, evaluateDeployPlan } from './risk-rule-engine.mjs';
import { classifyTextCommand, redactSecrets } from './safety-policy.mjs';
import { planHcloudCommand, runHcloud, consumeApprovalToken, inspectApprovalToken, hashArgs } from './hcloud-cli.mjs';
import { checkAccountType } from './account-type.mjs';
import { searchMarketplace } from './search-market.mjs';
import { getServiceIcon } from './icon-library.mjs';
import { detectFramework } from './detect-framework.mjs';
import {
  execWithSession,
  execOneShot,
  closeSession,
  uploadFileWithSession,
  uploadProjectWithSession,
  deployNginx,
  deployCheck,
  exposeTunnel,
  renewTunnel,
  installKeepaliveWatchdog,
  getCurrentWorkspaceId,
  setWorkspaceId,
} from './sandbox/session-manager.mjs';
import {
  hdkitCheckUser,
  hdkitSignAgreement,
  hdkitConnect,
  hdkitCredentials,
  hdkitVoucherStatus,
  hdkitVoucherClaim,
  hdkitCompetitionVoucherClaim,
  hdkitGenerateUserHash,
} from './sandbox/hdkitservice-api.mjs';
import { getCredentials } from './sandbox/hwlink-api.mjs';
import { getAuthStatus, syncAuth } from './auth/service.mjs';
import { validateIamCredentials } from './auth/credential-validator.mjs';
import {
  readGlobalCredentials,
  writeGlobalCredentials,
  writeObsConfig as writeObsConfigFile,
  setRuntimeCredentials,
  clearRuntimeCredentials,
  setConfiguredBySession,
  backupGlobalCredentials,
  writeLastSync,
  readCodeArtsCredentials,
  globalCredentialsPath,
  parseStsExpiry,
  resolveCredentialsWithRuntime,
} from './auth/credentials.mjs';
import { trackToolInvoke, trackSkillRetrieve, clearUserHash } from './telemetry/telemetry.mjs';
import { fetchWithProxy } from './proxy/proxy-agent.mjs';
import { fingerprint, runHcloudConfigure, runHcloudProfileDelete, resolveManagedProfile } from './auth/reconcile.mjs';
import {
  getCachedUpdateInfo,
  getUpdateDistTags,
  invalidateUpdateCache,
  judgeUpdate,
  determineTarget,
  readInstalledVersion,
  writeSkipState,
  resolveSkipFilePath,
  upgradePackage,
} from './update-check.mjs';
import { hcloudProbeNextStep, hcloudProbeRaw, probeHcloud } from './hcloud-probe.mjs';
import { isUsableOfficeaceRoot, readOfficeaceRootMarker } from './officeace-paths.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SKILLS_ROOT_DEV = join(__dirname, '..', 'skills');
function opencodeSkillsDir() {
  const home = homedir();
  return join(home, '.config', 'opencode', 'skills');
}
function codeartsSkillsDir() {
  const home = homedir();
  return join(home, '.codeartsdoer', 'skills');
}
function codeartsWorkSkillsDir() {
  const home = homedir();
  return join(home, '.codeartswork', 'skills');
}
function workbuddySkillsDir() {
  const home = homedir();
  return join(home, '.workbuddy', 'skills');
}
function dshSkillsDir() {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh');
  return join(home, 'skills');
}
function readOfficeaceRegistryInstallDir() {
  if (process.platform !== 'win32') return null;
  try {
    const r = spawnSync('reg', ['query', 'HKCU\\SOFTWARE\\OfficeAce\\OfficeAce', '/v', 'InstallDir'], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 5000,
    });
    if (r.status === 0) {
      const m = r.stdout.match(/InstallDir\s+REG_SZ\s+(.+)/);
      if (m) return m[1].trim();
    }
  } catch {}
  return null;
}

function officeaceSkillsRoot() {
  const configRoot = process.env.OFFICE_CLAW_CONFIG_ROOT;
  // Same lenient probe as the installer (isUsableOfficeaceRoot) so env pointing
  // at "skills present but capabilities.json absent" resolves identically at
  // install and at runtime (#559 review).
  if (configRoot && isUsableOfficeaceRoot(configRoot)) return join(configRoot, 'skills');
  // Same persisted root used by the installer keeps install-time and
  // runtime skill discovery consistent (#559).
  const markerRoot = readOfficeaceRootMarker();
  if (markerRoot) return join(markerRoot, 'skills');
  const regDir = readOfficeaceRegistryInstallDir();
  if (regDir) {
    const dir = join(regDir, '.office-claw', 'skills');
    if (existsSync(dir)) return dir;
  }
  if (process.platform === 'win32') {
    const bases = [process.env.ProgramFiles, 'C:\\Program Files', 'D:\\Program Files'];
    if (process.env.LOCALAPPDATA) bases.push(join(process.env.LOCALAPPDATA, 'Programs'));
    for (const base of bases) {
      if (!base) continue;
      const dir = join(base, 'OfficeAce', '.office-claw', 'skills');
      if (existsSync(dir)) return dir;
    }
  }
  return null;
}

function hermesSkillsDir() {
  if (process.env.HERMES_HOME) return join(process.env.HERMES_HOME, 'skills');
  // Hermes on Windows stores under LOCALAPPDATA, not ~/.hermes
  if (process.platform === 'win32' && process.env.LOCALAPPDATA) {
    return join(process.env.LOCALAPPDATA, 'hermes', 'skills');
  }
  const home = homedir();
  return join(home, '.hermes', 'skills');
}

function atomcodeSkillsDir() {
  const home = process.env.ATOMCODE_HOME || homedir();
  return join(home, '.atomcode', 'skills');
}

function codexDesktopSkillsDir() {
  return join(homedir(), '.agents', 'skills');
}

export function listSkillDirs(root) {
  if (!existsSync(root)) return [];
  try {
    return readdirSync(root, { withFileTypes: true })
      .filter((d) => (d.isDirectory() || d.isSymbolicLink()) && existsSync(join(root, d.name, 'SKILL.md')))
      .map((d) => d.name);
  } catch {
    return [];
  }
}

export function findSkillsRoot(candidates) {
  for (const dir of candidates) {
    if (listSkillDirs(dir).length > 0) return dir;
  }
  return null;
}

function resolveSkillsRoot() {
  return (
    findSkillsRoot([
      SKILLS_ROOT_DEV,
      dshSkillsDir(),
      codeartsSkillsDir(),
      codeartsWorkSkillsDir(),
      opencodeSkillsDir(),
      workbuddySkillsDir(),
      officeaceSkillsRoot(),
      hermesSkillsDir(),
      atomcodeSkillsDir(),
      codexDesktopSkillsDir(),
    ]) || SKILLS_ROOT_DEV
  );
}
const SKILLS_ROOT = resolveSkillsRoot();

export const TOOL_DEFINITIONS = [
  {
    name: 'huaweicloud_check_cli',
    description:
      'Check whether Huawei Cloud KooCLI hcloud is installed and whether its version matches the plugin paired version. Returns redacted output.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'huaweicloud_plan_cli_command',
    description: 'Classify and plan a Huawei Cloud hcloud command without executing it.',
    inputSchema: {
      type: 'object',
      required: ['args'],
      properties: {
        args: {
          type: 'array',
          items: { type: 'string' },
          description: 'hcloud arguments, excluding the hcloud executable.',
        },
        allowWrites: {
          type: 'boolean',
          description: 'Only true after explicit user approval for this exact operation.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_run_readonly_command',
    description: 'Run a read-only hcloud command through the toolkit safety policy and redact output.',
    inputSchema: {
      type: 'object',
      required: ['args'],
      properties: {
        args: {
          type: 'array',
          items: { type: 'string' },
        },
        timeoutMs: {
          type: 'number',
          description: 'Optional timeout in milliseconds. Defaults to 60000.',
        },
        maxRetries: {
          type: 'number',
          description: 'Optional retry count for transient network errors. Defaults to 1.',
        },
        cwd: {
          type: 'string',
          description: 'Optional working directory for the hcloud process.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_list_operations',
    description:
      'List KooCLI operations for a Huawei Cloud service by running local/read-only hcloud <Service> --help.',
    inputSchema: {
      type: 'object',
      required: ['service'],
      properties: {
        service: {
          type: 'string',
          description: 'KooCLI service name, such as ECS, VPC, IMS, OBS, RDS, or CDN.',
        },
        timeoutMs: {
          type: 'number',
          description: 'Optional timeout in milliseconds. Defaults to 60000.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_run_approved_command',
    description:
      'Run a write-capable hcloud command only after the exact command has been shown and explicitly approved by the user.',
    inputSchema: {
      type: 'object',
      required: ['args', 'approvalToken', 'approvedByUser'],
      properties: {
        args: {
          type: 'array',
          items: { type: 'string' },
          description: 'hcloud arguments, excluding the hcloud executable.',
        },
        approvalToken: {
          type: 'string',
          description: 'The approvalToken returned by huaweicloud_plan_cli_command.',
        },
        approvedByUser: {
          type: 'boolean',
          description: 'Must be true only after the user explicitly approves this exact command.',
        },
        timeoutMs: {
          type: 'number',
          description: 'Optional timeout in milliseconds. Defaults to 60000.',
        },
        maxRetries: {
          type: 'number',
          description: 'Optional retry count for transient network errors. Defaults to 1.',
        },
        cwd: {
          type: 'string',
          description: 'Optional working directory for the hcloud process.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_show_profile_redacted',
    description: 'Inspect a KooCLI profile through hcloud configure show and return only redacted output.',
    inputSchema: {
      type: 'object',
      properties: {
        profile: {
          type: 'string',
          description: 'Optional KooCLI profile name.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_hook_check_command',
    description: 'Check a planned shell or hcloud command against Huawei Cloud hook risk rules without executing it.',
    inputSchema: {
      type: 'object',
      required: ['command'],
      properties: {
        command: { type: 'string', description: 'The exact command text to inspect.' },
      },
    },
  },
  {
    name: 'huaweicloud_hook_check_artifacts',
    description: 'Check generated code, IaC, policy, or config artifacts against Huawei Cloud hook risk rules.',
    inputSchema: {
      type: 'object',
      required: ['artifacts'],
      properties: {
        artifacts: {
          type: 'array',
          items: {
            type: 'object',
            required: ['path', 'content'],
            properties: {
              path: { type: 'string' },
              content: { type: 'string' },
            },
          },
        },
      },
    },
  },
  {
    name: 'huaweicloud_hook_check_deploy_plan',
    description:
      'Check a structured or textual deployment plan for Huawei Cloud sandbox, exposure, IAM, and cost risks.',
    inputSchema: {
      type: 'object',
      required: ['plan'],
      properties: {
        plan: {
          description: 'Deployment plan as an object, array, or string.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_service_catalog',
    description: 'Return the recommended capability sources for Huawei Cloud agent tasks.',
    inputSchema: {
      type: 'object',
      properties: {
        intent: {
          type: 'string',
          description: 'Developer intent to route, such as deploy app, use API, debug error, or inspect resources.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_explain_error',
    description: 'Explain a Huawei Cloud CLI, API, SDK, or agent workflow error and suggest next diagnostic steps.',
    inputSchema: {
      type: 'object',
      properties: {
        service: { type: 'string' },
        errorCode: { type: 'string' },
        message: { type: 'string' },
        requestId: { type: 'string' },
      },
    },
  },
  {
    name: 'huaweicloud_search_docs',
    description:
      'Search across Huawei Cloud SKILL.md files and local documentation. Returns top 10 relevant results with source, name, snippet, and relevance score. Use when the agent needs to discover which skill covers a topic, or when uncertain about API parameters, quotas, or limitations.',
    inputSchema: {
      type: 'object',
      required: ['query'],
      properties: {
        query: { type: 'string', description: 'Search query across skill descriptions and documentation.' },
        topic: {
          type: 'string',
          description: 'Optional filter: all | ecs | obs | vpc | iam | rds | cce | modelarts | dew. Defaults to all.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_retrieve_skill',
    description:
      'Retrieve a full SKILL.md by skill name. Returns the complete skill content plus list of reference files. Use when the agent has identified which skill to load and needs the full procedure.',
    inputSchema: {
      type: 'object',
      required: ['name'],
      properties: {
        name: { type: 'string', description: 'Skill name, e.g., huaweicloud-core, huawei-ecs, huawei-obs.' },
      },
    },
  },
  {
    name: 'huaweicloud_list_regions',
    description:
      'List available Huawei Cloud regions. Returns region IDs, display names, and endpoints. Use when the agent needs to discover available regions before creating resources.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'huaweicloud_check_account_type',
    description:
      'Check whether the current credentials belong to the primary account or an IAM sub-user. Runs STS GetCallerIdentity + IAM KeystoneListAuthDomains (both read-only, no identity-policy permission required) and applies the validated rule: username == domainName -> primary account, otherwise IAM sub-user. Use before sandbox deployment (primary-account prechecks), account confirmation, or any task that needs to know who the current AK/SK belongs to. Returns isPrimaryAccount, applicable, domainId, domainName, userId, username, principalUrn, and an evidence string. Agency-session credentials are detected and reported as applicable:false.',
    inputSchema: {
      type: 'object',
      properties: {
        region: {
          type: 'string',
          description:
            'Optional region ID for the region-level GetCallerIdentity endpoint (e.g., cn-north-4). Defaults to the configured cli-region.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_get_regional_availability',
    description:
      'Check if a specific Huawei Cloud service is available in a target region. Use before creating resources to prevent failures from regional unavailability.',
    inputSchema: {
      type: 'object',
      required: ['service', 'region'],
      properties: {
        service: {
          type: 'string',
          description: 'Service name: ecs, obs, rds, gaussdb, cce, modelarts, functiongraph, etc.',
        },
        region: { type: 'string', description: 'Region ID: cn-south-1, cn-north-4, ap-southeast-3, etc.' },
      },
    },
  },
  {
    name: 'huaweicloud_search_marketplace',
    description:
      'Search the Huawei Cloud agent skill marketplace for available skills. Returns scored results with names, categories, and descriptions. Use when built-in skills are insufficient or the user asks what skills exist.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Search query across skill name, description, triggers, and service.' },
        category: {
          type: 'string',
          description: 'Optional category filter: computing, storage, network, security, devtools, monitoring, etc.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_get_service_icon',
    description:
      'Find the official Huawei Cloud service logo from the Huawei Cloud Icons library (open.huaweicloud.com/openplatform/icons.html). Returns top 5 matches with CDN logo URLs, local paths, category, aliases, and product page links. Provide service (e.g. ecs, obs, modelarts, 对象存储) or category (e.g. 计算, 存储, 人工智能) to browse. Use when generating PPT, architecture diagrams (draw.io), or frontend pages that need official Huawei Cloud service logos.',
    inputSchema: {
      type: 'object',
      properties: {
        service: {
          type: 'string',
          description:
            'Service name, alias, or Chinese name, e.g. ecs, obs, modelarts, 对象存储, 虚拟私有云. Omit to browse by category only.',
        },
        category: {
          type: 'string',
          description: 'Optional category filter, e.g. 计算, 存储, 网络, 人工智能, 数据库, 安全, 企业应用.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_detect_framework',
    description:
      'Scan a local project directory to identify the web framework (React/Vue/Angular/Next.js/Nuxt/VitePress/Docusaurus/Hugo/Hexo/Taro/uni-app), package manager, and monorepo tool. Returns framework type, build commands, output directory, and port. Use before deploying a web application to determine the correct build pipeline.',
    inputSchema: {
      type: 'object',
      required: ['projectPath'],
      properties: {
        projectPath: { type: 'string', description: 'Absolute path to the local project directory to scan.' },
      },
    },
  },
  {
    name: 'huaweicloud_setup_obs_config',
    description:
      'Synchronize KooCLI credentials to OBS config (~/.obsutilconfig). KooCLI and OBS use separate credential stores — hcloud commands work fine but OBS commands fail with "Please set ak, sk" unless this sync is done. Run this once to enable OBS operations; re-run after changing hcloud credentials.',
    inputSchema: {
      type: 'object',
      properties: {
        profile: { type: 'string', description: 'Optional KooCLI profile name. Uses the active profile by default.' },
      },
    },
  },
  {
    name: 'huaweicloud_auth_status',
    description:
      'Check unified Huawei Cloud authentication status across the global credential vault, OBS, KooCLI, and all supported agent MCP registrations. Returns only redacted/status information, never credentials.',
    inputSchema: {
      type: 'object',
      properties: {
        target: {
          type: 'string',
          description:
            'Agent target to check: opencode, codex, codex-desktop, codearts, codearts-work, workbuddy, dsh, officeace, hermes, openclaw, atomcode, or all (default).',
        },
      },
    },
  },
  {
    name: 'huaweicloud_auth_sync',
    description:
      'Synchronize credentials from the global Huawei Cloud credential vault to OBS and report agent registration status. Does not write secrets into any agent config.',
    inputSchema: {
      type: 'object',
      properties: {
        target: {
          type: 'string',
          description:
            'Agent target to report after sync: opencode, codex, codex-desktop, codearts, codearts-work, workbuddy, dsh, officeace, hermes, or all (default).',
        },
      },
    },
  },
  {
    name: 'huaweicloud_auth_init',
    description:
      'Set or clear runtime Huawei Cloud credentials (AK/SK) for this MCP session. Runtime credentials take highest priority over environment variables and config files for all subsequent API calls. Use when switching accounts within the same Agent session — call with AK/SK to switch, or with clear=true to fall back to env/file credentials.',
    inputSchema: {
      type: 'object',
      properties: {
        ak: { type: 'string', description: 'Huawei Cloud Access Key (required unless clear=true)' },
        sk: { type: 'string', description: 'Huawei Cloud Secret Key (required unless clear=true)' },
        region: { type: 'string', description: 'Default region (optional)' },
        clear: { type: 'boolean', description: 'Set to true to clear runtime credentials and revert to env/file' },
      },
    },
  },
  {
    name: 'huaweicloud_auth_switch',
    description:
      'Switch Huawei Cloud credentials within the current session. action=temporary keeps AK/SK in memory only (restart loses them; hcloud commands are unaffected and an A+C warning will be raised). action=persist writes S1 (single source of truth) with configuredBySession flag and propagates to S2 (KooCLI current profile) and S3 (OBS). action=clear resets runtime credentials. mode=import reads AK/SK from ~/.config/huaweicloud/creds-import.json then wipes it (SK never enters conversation). mode=memory passes AK/SK as tool arguments (SK is visible to model - prefer import). mode=mcp-config reads the injected mcp_settings environment.',
    inputSchema: {
      type: 'object',
      properties: {
        mode: { type: 'string', enum: ['import', 'memory', 'mcp-config'], description: 'Credential source channel' },
        action: { type: 'string', enum: ['persist', 'temporary', 'clear'], description: 'Apply scope' },
        ak: { type: 'string' },
        sk: { type: 'string' },
        securityToken: { type: 'string' },
        region: { type: 'string' },
      },
    },
  },
  {
    name: 'huaweicloud_auth_confirm',
    description:
      'Confirm a pending credential reconciliation choice returned by auth_switch persist when S1 already holds a different account (R2). decision=s1 keeps S1 as source of truth and propagates it; decision=newImported propagates the newly imported account into S1 and mirrors.',
    inputSchema: {
      type: 'object',
      properties: {
        token: { type: 'string', description: 'confirmation token from the needs_confirmation response' },
        decision: { type: 'string', enum: ['s1', 'newImported'] },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_exec_with_session',
    description:
      'Execute a command on a workspace terminal with session reuse (state persists across calls). Shell state (cd, env vars, aliases) carries over between calls. Use for interactive work and command sequences that need shared state. NOT for long-running commands (>30s) — prefer exec_one_shot for those.',
    inputSchema: {
      type: 'object',
      required: ['command'],
      properties: {
        command: { type: 'string', description: 'The shell command to execute on the remote workspace' },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username for the remote terminal (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 120000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_exec_one_shot',
    description:
      'Execute a command on a workspace terminal with a fresh connection per call (no session state carries over). Each invocation opens a new WebSocket connection, executes one command, then disconnects. Use for long-running build/deploy/install commands (>30s) that do not need shell state persistence between calls. More stable than session-based execution for heavy workloads.',
    inputSchema: {
      type: 'object',
      required: ['command'],
      properties: {
        command: { type: 'string', description: 'The shell command to execute on the remote workspace' },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username for the remote terminal (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 120000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_close_session',
    description: 'Close the persistent terminal session for a workspace.',
    inputSchema: {
      type: 'object',
      properties: {
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_upload_file',
    description:
      'Upload a local file into the sandbox workspace. Base64-encodes the file, writes it in small chunks through the terminal session (the exec channel is fragile for large single commands), then decodes and verifies the md5 checksum. The remote parent directory is created automatically if absent. Use this instead of embedding large file content directly in a command. local_path must be readable from the machine running the DevKit MCP server — if the file lives elsewhere, copy it to the local temp directory first.',
    inputSchema: {
      type: 'object',
      required: ['local_path', 'remote_path'],
      properties: {
        local_path: {
          type: 'string',
          description:
            'Absolute path to the local file, readable from the machine running the DevKit MCP server (copy to the local temp dir first if not).',
        },
        remote_path: { type: 'string', description: 'Target path in the sandbox, e.g. /workspace/<repo>/index.html.' },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 60000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_upload_project',
    description:
      'Package a local project directory and upload it to a sandbox workspace via HTTP tunnel. Falls back to base64 chunking if tunnel fails. Creates a tar.gz archive, uploads it, and extracts it on the sandbox by default. local_dir must be readable from the machine running the DevKit MCP server — if the project lives elsewhere, copy it to the local temp directory first.',
    inputSchema: {
      type: 'object',
      required: ['local_dir'],
      properties: {
        local_dir: {
          type: 'string',
          description:
            'Local project directory, readable from the machine running the DevKit MCP server (copy to the local temp dir first if not).',
        },
        remote_dir: {
          type: 'string',
          description:
            'Remote parent directory where project will be extracted (default: /workspace). Final layout: <remote_dir>/<dirname>/',
        },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        exclude: {
          type: 'array',
          items: { type: 'string' },
          description: 'Patterns to exclude from archive (default: .git, node_modules, __pycache__, .venv)',
        },
        extract: {
          type: 'boolean',
          description: 'Extract tar.gz on sandbox after upload (default: true)',
        },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 300000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_deploy_nginx',
    description:
      'Deploy an nginx configuration on the sandbox and reload. Takes nginxType, port, project, outputDir from framework detection and writes the correct template (SPA try_files, SSR reverse proxy, or static). Also fixes directory traverse permissions on the project path. Use this instead of manually constructing nginx config — it handles permissions, template selection, and reload in one call. If the requested port is already in use, the actual port is auto-incremented and returned in "port" alongside a warning.',
    inputSchema: {
      type: 'object',
      required: ['nginx_type', 'port', 'project', 'output_dir'],
      properties: {
        nginx_type: {
          type: 'string',
          description:
            'Nginx config type from framework detection: spa (try_files fallback for SPA/SSG/cross-platform), proxy (reverse proxy for SSR), or static (plain root for Hugo/Hexo).',
          enum: ['spa', 'proxy', 'static'],
        },
        port: { type: 'number', description: 'Listen port (from framework detection).' },
        project: { type: 'string', description: 'Project directory name under /workspace, e.g. movie-ticket.' },
        output_dir: {
          type: 'string',
          description: 'Build output directory relative to /workspace/<project>, e.g. dist/build/h5.',
        },
        node_port: { type: 'number', description: 'Node.js app port for SSR (required when nginx_type=proxy).' },
        public_port: { type: 'number', description: 'Public listen port for SSR proxy (optional, defaults to port).' },
        config_name: {
          type: 'string',
          description:
            'Config file name (without .conf suffix). Defaults to the project name, ensuring each project gets its own config. Override with distinct names (e.g. admin, docs) for sub-app deployments.',
        },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 30000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_deploy_check',
    description:
      'Run a deployment completeness check on the sandbox. Verifies nginx is serving, output directory exists, DevBridge tunnel is active and accessible, and QR code exists (cross-platform). Returns a score, nextStep, and (when the DevBridge tunnel is missing) an executable "remediation" command string. Call this at the end of a deployment workflow to confirm everything is working before reporting success.',
    inputSchema: {
      type: 'object',
      required: ['port', 'project', 'output_dir'],
      properties: {
        port: { type: 'number', description: 'App listen port (from framework detection).' },
        project: { type: 'string', description: 'Project directory name under /workspace.' },
        output_dir: {
          type: 'string',
          description: 'Build output directory relative to /workspace/<project>, e.g. dist/build/h5.',
        },
        framework_type: {
          type: 'string',
          description: 'Framework type from detect_framework. Set to cross-platform for QR code check.',
          enum: ['spa', 'ssr', 'ssg', 'cross-platform', 'monorepo', 'static'],
        },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 30000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_expose_tunnel',
    description:
      'Expose a port on the sandbox to a public DevBridge tunnel URL (devbridge 0.2.x). Authenticates automatically (probing AK/SK vs API-Key builds, using /tmp/hw_creds.sh and /tmp/hw_api_key as injected by huaweicloud_sandbox_credentials), pre-cleans stale tunnels to avoid quota errors, starts the host, extracts the public URL (https://<id>-<port>.devbridge-s2.hwtunnel.com), and health-checks it before returning. AUTO-ENROLLS the tunnel into the keepalive watchdog (host re-attach + daily 720h renewal + health check) by default, merged into existing coverage — pass keepalive:false to opt out. Use the ACTUAL port reported by huaweicloud_sandbox_deploy_nginx (its "port" field auto-increments on conflict) — never the originally requested port. Returns ok, publicUrl, port, tunnelId, keepalive.enrolled, and warnings. If the API Key is missing on a release build it returns ok:false with instructions to create one.',
    inputSchema: {
      type: 'object',
      required: ['port'],
      properties: {
        port: {
          type: 'number',
          description:
            'Actual port nginx is listening on — use the "port" value returned by huaweicloud_sandbox_deploy_nginx, not the originally requested port.',
        },
        expiry_hours: {
          type: 'number',
          description:
            'Tunnel lifetime in hours via devbridge -e (1-720; 720 = the 30-day maximum, default 72). The expiry is a rolling window — the keepalive watchdog renews daily to keep the URL alive indefinitely.',
        },
        keepalive: {
          type: 'boolean',
          description:
            'Auto-enroll the tunnel into the keepalive watchdog (default true — every tunnel deployed to the sandbox must be keepalive-protected). Pass false only when the caller explicitly manages keepalive itself.',
        },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 90000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_renew_tunnel',
    description:
      'Renew a DevBridge tunnel lifetime via devbridge update <tunnelId> -e <hours> (1-720; 720 = the 30-day maximum). The expiry is a rolling window: renewal sets expiration = now + hours regardless of remaining time, so renewing before expiry keeps the SAME tunnel URL alive indefinitely. A renewal counts as ok only when the update succeeds AND show -v reports the absolute tunnelExpiration — the management plane can lose a tunnel record (10002 "tunnel not found") while the data plane keeps serving. Returns ok, tunnelId, expiresAt (ISO), renewedForHours. Pair with huaweicloud_sandbox_keepalive_watchdog for unattended daily renewal.',
    inputSchema: {
      type: 'object',
      required: ['tunnel_id'],
      properties: {
        tunnel_id: {
          type: 'string',
          description:
            'Short tunnel ID from huaweicloud_sandbox_expose_tunnel (e.g. nv2dvv6w) — extractable from the public URL as https://<tunnel_id>-<port>.devbridge-s2.hwtunnel.com.',
        },
        expiry_hours: {
          type: 'number',
          description:
            'Renewal horizon in hours (1-720, default 720). The expiration becomes now + expiry_hours (rolling window).',
        },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 60000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_keepalive_watchdog',
    description:
      'Install a keepalive watchdog in the sandbox that keeps DevBridge tunnel URLs alive indefinitely (three-layer pattern, proven in the 2026-10 tunnel-persistence test): (1) re-attaches the host with devbridge host <tunnelId> if the process dies — the URL is bound to the tunnel ID so it never changes; (2) renews every tunnel daily with devbridge update <tunnelId> -e 720 (29-day failure tolerance); (3) health-checks each URL every 5 minutes, logging warnings to /tmp/tunnel-keepalive.log. Installs as a setsid-detached loop at /tmp/tunnel-keepalive.sh; re-running replaces the old loop. URLs are hardcoded per tunnel because devbridge port list output is wrapped in OSC escapes that break anchored greps. Call AFTER huaweicloud_sandbox_expose_tunnel; requires DevBridge credentials (auth) in the sandbox.',
    inputSchema: {
      type: 'object',
      required: ['tunnels'],
      properties: {
        tunnels: {
          type: 'array',
          description:
            'Tunnels to watch. Get tunnelId + url from huaweicloud_sandbox_expose_tunnel (publicUrl contains the tunnelId as https://<tunnel_id>-<port>.devbridge-s2.hwtunnel.com).',
          items: {
            type: 'object',
            required: ['tunnel_id', 'url'],
            properties: {
              tunnel_id: { type: 'string', description: 'Short tunnel ID (e.g. kag7rozs).' },
              url: { type: 'string', description: 'Full public https URL of the tunnel (used for the health check).' },
            },
          },
        },
        workspace_id: {
          type: 'string',
          description:
            'Workspace ID from huaweicloud_sandbox_connect return value. Required - must be passed explicitly when HW_WORKSPACE_ID is not set.',
        },
        username: { type: 'string', description: 'Login username (default: root)' },
        timeout_ms: { type: 'number', description: 'Execution timeout in milliseconds (default: 60000)' },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_check_user',
    description:
      'Check if the current user has completed real-name verification and signed the required agreements. Returns 200 {realnameVerified, agreementSigned} when all good; throws 403 HDKIT_NOT_REALNAME / HDKIT_NOT_AGREEMENT / HDKIT_NOT_REALNAME_AND_AGREEMENT to indicate what is missing. Never signs anything itself.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'huaweicloud_sandbox_sign_agreement',
    description:
      "Sign all unsigned or outdated agreements for the current user. Required before huaweicloud_sandbox_connect if check-user returns agreementSigned=false. CRITICAL: only call after the user explicitly consents to signing — never sign agreements on the user's behalf without their explicit request.",
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'huaweicloud_sandbox_connect',
    description:
      'Connect to a sandbox via hdkitservice. One user one instance - reuses existing sandbox if available, otherwise creates a new one. Returns session_id, dev_stage_id, connection_id, connection_address, and expiresAt (STS credential expiry).',
    inputSchema: {
      type: 'object',
      properties: {
        source: {
          type: 'string',
          description:
            'Source identifier (default: WEB). Options: VSCODE, CLI, WEB, WEBVNC, WEBPTY, WEBIDE, CURSOR, etc.',
        },
        template_id: { type: 'string', description: 'Template ID; overrides server default (only for new sandbox)' },
        flavor_id: { type: 'string', description: 'Flavor ID; overrides server default (only for new sandbox)' },
        env: { type: 'object', description: 'Environment variables to set in the sandbox (only for new sandbox)' },
        git: {
          type: 'object',
          description: 'Git repo config (only for new sandbox)',
          properties: {
            repo_url: { type: 'string', description: 'Git repository URL' },
            repo_branch: { type: 'string', description: 'Git branch' },
            repo_name: { type: 'string', description: 'Repository name' },
            target_path: { type: 'string', description: 'Clone target path in sandbox' },
            open_type: { type: 'string', description: 'Open type' },
          },
        },
      },
    },
  },
  {
    name: 'huaweicloud_sandbox_credentials',
    description:
      'Configure temporary AK/SK for a sandbox via hdkitservice. Validates the current AK/SK against IAM before injecting (invalid SK is rejected here instead of failing later with APIGW.0301 during exec), then injects temporary credentials into the sandbox. Also injects an optional DevBridge API Key — required for devbridge 0.2.x tunnel exposure because 0.2.x removed AK/SK login. The API Key is a long-lived account-level credential, so it is stored in a separate file (/tmp/hw_api_key, 0600) from the temporary AK/SK (/tmp/hw_creds.sh). Source of truth: local HW_API_KEY env first, then the api_key param. The sandbox must be in RUNNING state.',
    inputSchema: {
      type: 'object',
      properties: {
        session_id: { type: 'string', description: 'Session ID from huaweicloud_sandbox_connect' },
        dev_stage_id: { type: 'string', description: 'DevStation environment ID (alternative to session_id)' },
        enable_sts: { type: 'boolean', description: 'Whether to enable STS temporary AK/SK (default: true)' },
        region: {
          type: 'string',
          description:
            'Region used for IAM credential validation and project_id resolution (defaults to the configured region)',
        },
        api_key: {
          type: 'string',
          description:
            'DevBridge API Key (devbridge_...), injected into the sandbox as HW_API_KEY for devbridge 0.2.x auth. The local HW_API_KEY environment variable takes precedence over this param (preferred delivery — keeps the long-lived key out of the conversation). Users create one at https://devstation.connect.huaweicloud.com/space/devbridge/apikey (full value shown once at creation). Required for exposing web apps via devbridge 0.2.x; if missing, guide the user through creating one.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_voucher_status',
    description:
      '查询代金券领取状态。用户首次使用、开始会话或询问插件能力时，应主动调用本工具检查：未领取（claimed=false）则主动提示可领取一张代金券；已领取（claimed=true）则不提示、不打扰。',
    inputSchema: {
      type: 'object',
      properties: {
        domain_id: {
          type: 'string',
          description: 'Optional. Leave empty in production — account is resolved from IAM automatically.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_voucher_claim',
    description: '领取代金券（一人一次）。重复领取会返回已领取。',
    inputSchema: {
      type: 'object',
      properties: {
        domain_id: {
          type: 'string',
          description: 'Optional. Leave empty in production — account is resolved from IAM automatically.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_competition_voucher_claim',
    description:
      '领取华为开发者大赛·小红书skill创新赛专属华为云代金券。前置条件：用户已完成该赛事报名（后端自动校验，未报名返回 code=HDKIT_NOT_SIGNED_UP）。仅当用户明确要求领取该赛事代金券时调用，不要主动提示。重复领取会返回已领取。',
    inputSchema: {
      type: 'object',
      properties: {
        domain_id: {
          type: 'string',
          description: 'Optional. Leave empty in production — account is resolved from IAM automatically.',
        },
      },
    },
  },
  {
    name: 'huaweicloud_check_update',
    description:
      '检查 huaweicloud-devkit 插件是否有新版本。结果含 currentVersion / latestStable / latestNext / targetVersion / updateAvailable / dismissExpiresAt / result。支持 dismiss:true 记录用户拒绝（3 天冷却，新版本会重新提醒）。',
    inputSchema: {
      type: 'object',
      properties: {
        dismiss: { type: 'boolean', description: '用户拒绝升级时传 true，记录冷却状态。' },
        dismissVersion: {
          type: 'string',
          description: '与 dismiss:true 搭配，用户拒绝的版本号。缺省时用当前检测到的 targetVersion。',
        },
      },
    },
  },
  {
    name: 'huaweicloud_upgrade',
    description:
      '升级 huaweicloud-devkit 到最新版本。执行前必须先征得用户同意。version 仅支持 "latest"。完成后需重启会话生效。',
    inputSchema: {
      type: 'object',
      properties: {
        version: { type: 'string', description: '仅支持 "latest"（默认）。' },
        target: {
          type: 'string',
          description: 'agent 目标（opencode/codex/codearts/.../all）。缺省时用 all（仅更新已安装的）。',
        },
      },
    },
  },
  {
    name: 'huaweicloud_obs_set_website_config',
    description:
      '配置 OBS 桶的静态网站托管。KooCLI OBS 不支持 SetBucketWebsite API，此工具内部实现 AWS4 签名调用 OBS REST API，屏蔽签名细节。支持 set（配置）、get（查询）、delete（删除）三种操作。操作前需确保桶已创建且已设置 public-read ACL。',
    inputSchema: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['set', 'get', 'delete'],
          description: '操作类型：set=配置静态网站托管，get=查询当前配置，delete=删除配置',
        },
        bucket: { type: 'string', description: 'OBS 桶名称' },
        region: { type: 'string', description: 'OBS 桶所在区域，如 cn-north-4' },
        indexDocument: {
          type: 'string',
          description: '首页文件名（action=set 时必填），如 index.html',
        },
        errorDocument: {
          type: 'string',
          description: '错误页面文件名（action=set 时可选），如 404.html 或 error.html',
        },
      },
      required: ['action', 'bucket', 'region'],
    },
  },
  {
    name: 'huaweicloud_obs_set_cors',
    description:
      '配置 OBS 桶的 CORS 规则（浏览器直传前置条件）。KooCLI OBS 不支持 cors 子命令，此工具内部实现 AWS4 签名调用 OBS REST API（PUT/GET/DELETE /?cors），屏蔽签名细节。支持 set（配置）、get（查询）、delete（删除）三种操作。allowedMethod 必须含 HEAD（BrowserJS SDK 每次操作前发 HEAD ?apiversion 探测，缺 HEAD 时浏览器吞掉探测请求）。配置成功后用返回体中的 verify 命令做 OPTIONS 预检验证（200 + Access-Control-Allow-Origin 才算成功）。',
    inputSchema: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['set', 'get', 'delete'],
          description: '操作类型：set=配置 CORS 规则，get=查询当前规则，delete=删除规则',
        },
        bucket: { type: 'string', description: 'OBS 桶名称' },
        region: { type: 'string', description: 'OBS 桶所在区域，如 cn-north-4' },
        rules: {
          type: 'array',
          description:
            'CORS 规则数组（action=set 时必填）。每条规则：allowedOrigin（如 https://your-app）、allowedMethod 数组（GET/PUT/POST/DELETE/HEAD，必须含 HEAD）、allowedHeader 数组（默认 ["*"]）、maxAgeSeconds（默认 3000）',
          items: {
            type: 'object',
            properties: {
              allowedOrigin: { type: 'string', description: '允许的来源，如 https://your-app.example.com 或 *' },
              allowedMethod: {
                type: 'array',
                items: { type: 'string' },
                description: '允许的 HTTP 方法，必须包含 HEAD',
              },
              allowedHeader: {
                type: 'array',
                items: { type: 'string' },
                description: '允许的请求头，默认 ["*"]',
              },
              maxAgeSeconds: { type: 'number', description: '预检结果缓存秒数，默认 3000' },
            },
            required: ['allowedOrigin', 'allowedMethod'],
          },
        },
      },
      required: ['action', 'bucket', 'region'],
    },
  },
];

function toolInvokeValue(name, args) {
  if (name === 'huaweicloud_run_readonly_command' || name === 'huaweicloud_run_approved_command') {
    const cmdArgs = args.args || [];
    const filtered = cmdArgs.filter((a) => !a.startsWith('--') && !a.startsWith('-') && !a.includes('='));
    if (filtered.length >= 2) return `hcloud ${filtered.slice(0, 2).join(' ')}`;
  }
  if (name === 'huaweicloud_list_operations' && args.service) {
    return args.service;
  }
  if (name === 'huaweicloud_retrieve_skill' && args.name) {
    return args.name;
  }
  if (name === 'huaweicloud_hook_check_command' && args.command) {
    const parts = args.command.split(/\s+/).filter((p) => !p.startsWith('--'));
    if (parts[0] === 'hcloud' && parts[1]) return `hcloud ${parts.slice(1, 3).join(' ')}`;
    return parts.slice(0, 2).join(' ');
  }
  return '1';
}

const execFilePromise = promisify(execFile);

async function isGitAvailable() {
  try {
    await execFilePromise('git', ['--version'], { timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

async function gitCloneToLocal(repoUrl, branch, targetBasename) {
  const tempRoot = join(tmpdir(), `hw-sandbox-git-${Date.now()}`);
  const cloneDir = join(tempRoot, targetBasename);
  mkdirSync(tempRoot, { recursive: true });
  const args = ['clone', '--depth', '1'];
  if (branch) args.push('-b', branch);
  args.push(repoUrl, cloneDir);
  await execFilePromise('git', args, { timeout: 120000 });
  return { cloneDir, tempRoot };
}

async function transferGitRepo(args, devStageId, connectResult) {
  const git = args.git;
  if (!git?.repo_url || !git?.target_path) return;

  const { repo_url, repo_branch, target_path } = git;

  try {
    const existsCheck = await execOneShot(
      devStageId,
      `test -d "${target_path}/.git" && echo "EXISTS" || echo "NOT_EXISTS"`,
      'root',
      10000,
    );
    if (String(existsCheck.stdout || '').includes('EXISTS')) {
      connectResult._repoStatus = 'already_exists';
      return;
    }
  } catch {
    /* 检查失败继续 */
  }

  const hasGit = await isGitAvailable();
  if (hasGit) {
    let tempRoot = null;
    try {
      const targetName = basename(target_path);
      const { cloneDir, tempRoot: root } = await gitCloneToLocal(repo_url, repo_branch, targetName);
      tempRoot = root;
      await uploadProjectWithSession(devStageId, cloneDir, dirname(target_path), 'root', 300000, {
        extract: true,
        exclude: ['.git', 'node_modules'],
      });
      connectResult._repoStatus = 'uploaded_from_local';
      return;
    } catch {
      /* 本地方式失败，进入兜底 */
    } finally {
      if (tempRoot) {
        try {
          rmSync(tempRoot, { recursive: true, force: true });
        } catch {
          /* 清理失败忽略 */
        }
      }
    }
  }

  const branchFlag = repo_branch ? `-b ${repo_branch}` : '';
  await execOneShot(
    devStageId,
    `mkdir -p $(dirname "${target_path}") && git clone --depth 1 ${branchFlag} "${repo_url}" "${target_path}"`,
    'root',
    120000,
  );
  connectResult._repoStatus = 'cloned_in_sandbox';
}

const pendingConfirms = new Map();
// Tombstones for confirm tokens already consumed, so a repeat
// huaweicloud_auth_confirm call can be classified as already_processed
// instead of not_found (D4-24, #745). Kept in-memory only: confirm tokens
// are session-scoped and never persisted across processes.
const consumedConfirms = new Map();

function readImportFile() {
  const path = join(dirname(globalCredentialsPath()), 'creds-import.json');
  try {
    if (!existsSync(path)) return null;
    const data = JSON.parse(readFileSync(path, 'utf8'));
    return {
      ak: String(data.ak || ''),
      sk: String(data.sk || ''),
      securityToken: String(data.securityToken || ''),
      region: String(data.region || ''),
    };
  } catch {
    // Malformed/undecodable import file is un-replayable — wipe it. A VALID
    // file is kept so a rejected persist can be replayed (see #502).
    try {
      rmSync(path, { force: true });
    } catch {
      // ignore
    }
    return null;
  }
}

function clearImportFile() {
  const path = join(dirname(globalCredentialsPath()), 'creds-import.json');
  try {
    rmSync(path, { force: true });
  } catch {
    // best-effort: an absent or locked file is not an error
  }
}

function persistCredentials(ak, sk, securityToken, region) {
  if (String(securityToken || '')) {
    return {
      status: 'error',
      error: 'Temporary STS credentials cannot be persisted (R3). Use action=temporary.',
      scope: 'rejected',
    };
  }
  const before = backupGlobalCredentials();
  writeGlobalCredentials({ ak, sk: String(sk), securityToken: '', region, configuredBySession: true });
  setConfiguredBySession(true);
  let obs;
  try {
    writeObsConfigFile({ ak, sk, securityToken, region });
    obs = { ok: true };
  } catch (error) {
    obs = { ok: false, error: error.message };
  }
  const profile = resolveManagedProfile();
  let hcloud;
  if (!profile) {
    hcloud = { ok: false, reason: 'KooCLI current profile unresolved' };
  } else {
    // #920: `configure set` refuses an empty --cli-security-token, so a stale
    // token already in the profile survives the write and poisons every hcloud
    // call with APIGW.0301 — while the tool still reports "synchronized". When
    // persisting WITHOUT a token, walk the documented manual bypass
    // (delete the profile, then re-configure) so the on-disk profile truly
    // matches the incoming credentials. The delete is best-effort: a missing
    // profile ("nothing to clean") must not fail the persist.
    let profileReset = false;
    if (!String(securityToken || '')) {
      const deleted = runHcloudProfileDelete(profile);
      profileReset = deleted.ok || /not (exist|found)/i.test(deleted.error || '');
    }
    hcloud = runHcloudConfigure(profile, ak, sk, region);
    hcloud.profileReset = profileReset;
  }
  if (hcloud.ok) {
    writeLastSync({ kooCliProfile: profile, s1Fingerprint: fingerprint(ak, sk) });
  }
  return {
    status: obs.ok && hcloud.ok ? 'ok' : 'partial',
    scope: 'persist',
    backedUp: Boolean(before),
    obs: obs.ok ? { configured: true } : { configured: false, error: obs.error },
    hcloud,
    note: 'S1 written with configuredBySession (R9), which now takes priority over env-injected credentials; S2(current profile) and S3 synced. Persisting without a security token resets the target profile first (delete + recreate) so a stale token cannot survive the write (#920). Note: running `auth init` later clears the configuredBySession flag and env credentials regain priority.',
  };
}

function refreshUserHashAfterAuthChange({ regenerate = true } = {}) {
  clearUserHash();
  if (regenerate) {
    hdkitGenerateUserHash().catch(() => {});
  }
}

// Reject invalid numeric args up front instead of silently coercing them to
// NaN (which downstream defaults would absorb as "no timeout set") — see #530.
const NUMERIC_ARG_KEYS = ['timeoutMs', 'maxRetries', 'timeout_ms'];

function normalizeNumericArgs(args) {
  const out = { ...args };
  for (const key of NUMERIC_ARG_KEYS) {
    const value = out[key];
    if (value === undefined || value === null) continue;
    const num = Number(value);
    // timeouts must be positive; maxRetries may be 0 (means "no retries").
    const isRetries = key === 'maxRetries';
    const valid = Number.isFinite(num) && (isRetries ? Number.isSafeInteger(num) && num >= 0 : num > 0);
    if (!valid) {
      throw new Error(
        `Invalid parameter "${key}": expected a ${isRetries ? 'non-negative integer' : 'positive number'}, received ${JSON.stringify(value)}.`,
      );
    }
    out[key] = num;
  }
  return out;
}

export async function callTool(name, rawArgs = {}, opts = {}) {
  const args = normalizeNumericArgs(rawArgs);
  const toolValue = toolInvokeValue(name, args);
  trackToolInvoke(name, toolValue);

  switch (name) {
    case 'huaweicloud_check_cli':
      return runVersionCheck();
    case 'huaweicloud_plan_cli_command':
      return planHcloudCommand(args.args || [], { allowWrites: args.allowWrites === true });
    case 'huaweicloud_run_readonly_command':
      return runHcloud(args.args || [], {
        timeoutMs: args.timeoutMs,
        maxRetries: args.maxRetries,
        cwd: args.cwd,
        stdin: args.stdin,
      });
    case 'huaweicloud_list_operations':
      return listOperations(args.service, { timeoutMs: args.timeoutMs });
    case 'huaweicloud_run_approved_command':
      return runApprovedCommand(args);
    case 'huaweicloud_show_profile_redacted':
      return showProfileRedacted(args.profile);
    case 'huaweicloud_hook_check_command':
      return hookResult(evaluateCommandRisk(args.command || ''));
    case 'huaweicloud_hook_check_artifacts':
      return hookResult(evaluateArtifacts(args.artifacts || []));
    case 'huaweicloud_hook_check_deploy_plan':
      return hookResult(evaluateDeployPlan(args.plan || {}));
    case 'huaweicloud_service_catalog':
      return serviceCatalog(args.intent);
    case 'huaweicloud_search_docs':
      return searchDocs(args.query || '', args.topic || 'all');
    case 'huaweicloud_retrieve_skill':
      trackSkillRetrieve(args.name || '');
      return retrieveSkill(args.name || '');
    case 'huaweicloud_list_regions':
      return listRegions();
    case 'huaweicloud_check_account_type':
      return checkAccountType(args);
    case 'huaweicloud_get_regional_availability':
      return getRegionalAvailability(args.service || '', args.region || '');
    case 'huaweicloud_explain_error':
      return explainError(args);
    case 'huaweicloud_search_marketplace':
      return searchMarketplace(args.query || '', args.category || '');
    case 'huaweicloud_get_service_icon':
      return getServiceIcon(args.service || '', args.category || '');
    case 'huaweicloud_detect_framework': {
      const projectPath = args.projectPath;
      if (!projectPath) throw new Error('projectPath is required.');
      const result = detectFramework(projectPath);
      if (!result) {
        return { ok: false, error: 'No recognized web framework found in: ' + projectPath };
      }
      return { ok: true, ...result };
    }
    case 'huaweicloud_setup_obs_config':
      return setupObsConfig(args.profile);
    case 'huaweicloud_auth_status':
      return getAuthStatus(args.target || 'all');
    case 'huaweicloud_auth_sync': {
      const result = syncAuth(args.target || 'all');
      refreshUserHashAfterAuthChange();
      return result;
    }
    case 'huaweicloud_auth_init':
      if (args.clear) {
        clearRuntimeCredentials();
        refreshUserHashAfterAuthChange({ regenerate: false });
        return { status: 'cleared', message: 'Runtime credentials cleared. Fallback to env/file.' };
      }
      if (!args.ak || !args.sk) {
        throw new Error('ak and sk are required. Set clear=true to clear runtime credentials.');
      }
      setRuntimeCredentials(args.ak, args.sk, undefined, args.region);
      refreshUserHashAfterAuthChange();
      return { status: 'ok', message: 'Runtime credentials set for this MCP session.' };
    case 'huaweicloud_auth_switch': {
      const action = args.action || 'temporary';
      if (action === 'clear') {
        clearRuntimeCredentials();
        refreshUserHashAfterAuthChange({ regenerate: false });
        return { status: 'cleared', message: 'Runtime credentials cleared. Fallback to env/file/S1.' };
      }

      let ak = args.ak || '';
      let sk = args.sk || '';
      let securityToken = args.securityToken || '';
      let region = args.region || '';
      const sourceChannel = args.mode || 'memory';
      let importedFromFile = false;

      if (sourceChannel === 'import' && (!ak || !sk)) {
        const imported = readImportFile();
        if (imported) {
          ({ ak, sk, securityToken, region } = imported);
          importedFromFile = true;
        }
      }
      if (sourceChannel === 'mcp-config' && (!ak || !sk)) {
        const cc = readCodeArtsCredentials();
        if (cc) {
          ak = cc.ak;
          sk = cc.sk;
          securityToken = cc.securityToken || '';
          region = cc.region || region;
        }
      }

      if (!ak || !sk) {
        throw new Error('ak and sk are required (or provide creds-import.json for mode=import).');
      }

      if (action === 'persist' && !String(region || '').trim()) {
        return {
          status: 'error',
          scope: 'invalid_region',
          error:
            'region is required to persist credentials. Pass --region, or include "region" in creds-import.json (mode=import).',
        };
      }

      if (action === 'temporary') {
        setRuntimeCredentials(ak, sk, securityToken || undefined, region);
        refreshUserHashAfterAuthChange();
        if (importedFromFile) clearImportFile();
        return {
          status: 'ok',
          scope: 'temporary',
          note: 'Runtime credentials active for this MCP process. hcloud commands still use the KooCLI current profile; use action=persist to align files.',
        };
      }

      // action === 'persist'
      const prev = readGlobalCredentials();
      const conflict = prev?.ak && prev.ak !== ak;
      if (conflict) {
        backupGlobalCredentials();
        const token = `switch-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        pendingConfirms.set(token, {
          newAk: ak,
          newSk: sk,
          newSecurityToken: securityToken,
          newRegion: region,
          oldFingerprint: fingerprint(prev.ak, prev.sk),
          newFingerprint: fingerprint(ak, sk),
          fromImport: importedFromFile,
        });
        return {
          status: 'needs_confirmation',
          confirmToken: token,
          options: [
            { key: 's1', label: '以 S1 现有账号为准（不切换，恢复 backup）' },
            { key: 'newImported', label: `以新账号（${fingerprint(ak, sk)}）为准，覆盖 S1 并同步全部凭证文件` },
          ],
        };
      }

      const persisted = persistCredentials(ak, sk, securityToken, region);
      // Clear the import file for non-replayable outcomes (success, or an
      // unfixable rejection such as STS R3). Keep it only for a retryable
      // 'partial' (S1 written but a mirror failed).
      if (importedFromFile && persisted.status !== 'partial') clearImportFile();
      refreshUserHashAfterAuthChange();
      return persisted;
    }
    case 'huaweicloud_auth_confirm': {
      // D4-24 precise JSON contract (#745): a missing or already-consumed
      // confirm token returns a structured result instead of throwing a
      // generic Error string, mirroring runApprovedCommand's contract.
      const pending = pendingConfirms.get(args.token);
      if (!pending) {
        if (args.token && consumedConfirms.has(args.token)) {
          return { status: 'ok', outcome: 'already_processed' };
        }
        return { status: 'rejected', code: 'CONFIRM_TOKEN_NOT_FOUND' };
      }
      pendingConfirms.delete(args.token);
      consumedConfirms.set(args.token, { consumedAt: Date.now() });
      if (args.decision === 's1') {
        return { status: 'ok', outcome: 'aborted', message: '保持 S1 现有账号，未覆盖。' };
      }
      const confirmed = persistCredentials(pending.newAk, pending.newSk, pending.newSecurityToken, pending.newRegion);
      if (pending.fromImport && confirmed.status !== 'partial') clearImportFile();
      refreshUserHashAfterAuthChange();
      return confirmed;
    }
    case 'huaweicloud_sandbox_exec_with_session': {
      const sandboxWsId2 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId2) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser2 = args.username || 'root';
      const sandboxTimeout2 = args.timeout_ms || 120000;
      const sandboxResult2 = await execWithSession(sandboxWsId2, args.command, sandboxUser2, sandboxTimeout2);
      return { stdout: sandboxResult2.stdout, exitCode: sandboxResult2.exitCode };
    }
    case 'huaweicloud_sandbox_exec_one_shot': {
      const sandboxWsId3 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId3) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser3 = args.username || 'root';
      const sandboxTimeout3 = args.timeout_ms || 120000;
      const sandboxResult3 = await execOneShot(sandboxWsId3, args.command, sandboxUser3, sandboxTimeout3);
      return { stdout: sandboxResult3.stdout, exitCode: sandboxResult3.exitCode };
    }
    case 'huaweicloud_sandbox_close_session': {
      const sandboxWsId4 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId4) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser4 = args.username || 'root';
      const closed = await closeSession(sandboxWsId4, sandboxUser4);
      return closed ? 'ok' : 'not_connected';
    }
    case 'huaweicloud_sandbox_upload_file': {
      if (!args.local_path || !args.remote_path) {
        throw new Error('local_path and remote_path are required.');
      }
      const sandboxWsId5 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId5) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser5 = args.username || 'root';
      const sandboxTimeout5 = args.timeout_ms || 120000;
      return await uploadFileWithSession(
        sandboxWsId5,
        args.local_path,
        args.remote_path,
        sandboxUser5,
        sandboxTimeout5,
      );
    }
    case 'huaweicloud_sandbox_upload_project': {
      if (!args.local_dir) {
        throw new Error('local_dir is required.');
      }
      const sandboxWsId6 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId6) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser6 = args.username || 'root';
      const sandboxTimeout6 = args.timeout_ms || 120000;
      return await uploadProjectWithSession(
        sandboxWsId6,
        args.local_dir,
        args.remote_dir,
        sandboxUser6,
        sandboxTimeout6,
        {
          exclude: args.exclude,
          extract: args.extract,
        },
      );
    }
    case 'huaweicloud_sandbox_deploy_nginx': {
      if (!args.nginx_type || !args.port || !args.project || !args.output_dir) {
        throw new Error('nginx_type, port, project, and output_dir are required.');
      }
      const sandboxWsId7 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId7) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser7 = args.username || 'root';
      const sandboxTimeout7 = args.timeout_ms || 60000;
      return await deployNginx(
        sandboxWsId7,
        {
          nginxType: args.nginx_type,
          port: args.port,
          project: args.project,
          outputDir: args.output_dir,
          nodePort: args.node_port,
          publicPort: args.public_port,
          configName: args.config_name,
        },
        sandboxUser7,
        sandboxTimeout7,
      );
    }
    case 'huaweicloud_sandbox_deploy_check': {
      if (!args.port || !args.project || !args.output_dir) {
        throw new Error('port, project, and output_dir are required.');
      }
      const sandboxWsId8 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId8) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser8 = args.username || 'root';
      const sandboxTimeout8 = args.timeout_ms || 30000;
      return await deployCheck(
        sandboxWsId8,
        {
          port: args.port,
          project: args.project,
          outputDir: args.output_dir,
          frameworkType: args.framework_type,
        },
        sandboxUser8,
        sandboxTimeout8,
      );
    }
    case 'huaweicloud_sandbox_expose_tunnel': {
      if (!args.port) {
        throw new Error(
          'port is required. Use the ACTUAL "port" value returned by huaweicloud_sandbox_deploy_nginx (it may have been auto-incremented on a port conflict).',
        );
      }
      const sandboxWsId9 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId9) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const sandboxUser9 = args.username || 'root';
      const sandboxTimeout9 = args.timeout_ms || 90000;
      return await exposeTunnel(
        sandboxWsId9,
        { port: args.port, expiryHours: args.expiry_hours, keepalive: args.keepalive },
        sandboxUser9,
        sandboxTimeout9,
      );
    }
    case 'huaweicloud_sandbox_renew_tunnel': {
      if (!args.tunnel_id) {
        throw new Error(
          'tunnel_id is required. Get it from huaweicloud_sandbox_expose_tunnel or extract it from the public URL (https://<tunnel_id>-<port>.devbridge-s2.hwtunnel.com).',
        );
      }
      const sandboxWsId10 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId10) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      return await renewTunnel(
        sandboxWsId10,
        { tunnelId: args.tunnel_id, expiryHours: args.expiry_hours },
        args.username || 'root',
        args.timeout_ms || 60000,
      );
    }
    case 'huaweicloud_sandbox_keepalive_watchdog': {
      if (!Array.isArray(args.tunnels) || args.tunnels.length === 0) {
        throw new Error(
          'tunnels is required — a non-empty array of {tunnel_id, url} from huaweicloud_sandbox_expose_tunnel results.',
        );
      }
      const sandboxWsId11 = args.workspace_id || getCurrentWorkspaceId();
      if (!sandboxWsId11) {
        throw new Error(
          'workspace_id is required. No sandbox connected — call huaweicloud_sandbox_connect first, ' +
            'or set HW_WORKSPACE_ID environment variable before starting the agent.',
        );
      }
      const tunnels11 = args.tunnels.map((t) => ({ tunnelId: t.tunnel_id || t.tunnelId, url: t.url }));
      return await installKeepaliveWatchdog(
        sandboxWsId11,
        { tunnels: tunnels11 },
        args.username || 'root',
        args.timeout_ms || 60000,
      );
    }
    case 'huaweicloud_sandbox_check_user':
      return await hdkitCheckUser();
    case 'huaweicloud_sandbox_sign_agreement':
      return await hdkitSignAgreement();
    case 'huaweicloud_sandbox_connect': {
      const connectResult = await hdkitConnect(args);
      const devStageId = connectResult?.dev_stage_id || connectResult?.devStageId;
      if (devStageId) {
        setWorkspaceId(devStageId);
        try {
          await execOneShot(devStageId, 'devbridge delete-all 2>/dev/null || true', 'root', 15000);
        } catch {}
        try {
          await execWithSession(
            devStageId,
            'export PATH=/workspace/.local/bin:$HOME/.huawei/bin${PATH:+:$PATH}',
            'root',
            10000,
          );
        } catch {}
        await transferGitRepo(args, devStageId, connectResult);
      }
      return connectResult;
    }
    case 'huaweicloud_sandbox_credentials': {
      const devStageId = args.dev_stage_id || getCurrentWorkspaceId();
      let resolved;
      try {
        resolved = resolveCredentialsWithRuntime();
      } catch {
        resolved = null;
      }
      if (!resolved?.ak || !resolved?.sk) {
        return {
          ok: false,
          error: 'Huawei Cloud credentials are not configured. Nothing was injected into the sandbox.',
          hint: 'Run "npx huaweicloud-devkit auth init" or set HW_ACCESS_KEY/HW_SECRET_KEY, then retry.',
        };
      }
      const validation = await validateIamCredentials({
        ak: resolved.ak,
        sk: resolved.sk,
        securityToken: resolved.securityToken,
        region: args.region || resolved.region,
      });
      if (!validation.valid && !validation.skipped) {
        return {
          ok: false,
          error: 'Credential validation failed before injection: ' + validation.error,
          hint: 'Credentials were NOT injected into the sandbox. Fix AK/SK first: run "npx huaweicloud-devkit auth init" or correct HW_ACCESS_KEY/HW_SECRET_KEY, then retry.',
        };
      }
      const credResult = await hdkitCredentials(args.session_id, devStageId, args.enable_sts !== false);
      const sandboxWsIdCred = args.dev_stage_id || getCurrentWorkspaceId();
      // The DevBridge API Key is a LONG-LIVED account-level credential (no expiry, manual
      // revocation only) — unlike the temporary STS AK/SK. It is stored in its own file
      // (/tmp/hw_api_key, 0600) so an accidental dump of /tmp/hw_creds.sh never exposes it,
      // and the local HW_API_KEY env takes precedence over the tool param so the key can be
      // delivered without entering the conversation.
      const apiKey = process.env.HW_API_KEY || args.api_key || '';
      const apiKeyFile = '/tmp/hw_api_key';
      if (sandboxWsIdCred) {
        try {
          const { ak, sk, securitytoken } = getCredentials();
          const credsScript = [
            `export HW_ACCESS_KEY='${ak}'`,
            `export HW_SECRET_KEY='${sk}'`,
            securitytoken ? `export HW_SECURITY_TOKEN='${securitytoken}'` : '',
            securitytoken ? `export X_HW_SECURITY_TOKEN='${securitytoken}'` : '',
            validation.projectId ? `export HW_PROJECT_ID='${validation.projectId}'` : '',
          ]
            .filter(Boolean)
            .join('\n');
          const credsFile = '/tmp/hw_creds.sh';
          await execOneShot(
            sandboxWsIdCred,
            `cat > ${credsFile} << 'HWCREDS_EOF'\n${credsScript}\nHWCREDS_EOF\nchmod 600 ${credsFile}`,
            'root',
            15000,
          );
          await execWithSession(sandboxWsIdCred, `source ${credsFile} && echo "CREDS_SOURCED"`, 'root', 15000);
          if (apiKey) {
            await execOneShot(
              sandboxWsIdCred,
              `cat > ${apiKeyFile} << 'HWAPIKEY_EOF'\nexport HW_API_KEY='${apiKey}'\nHWAPIKEY_EOF\nchmod 600 ${apiKeyFile}`,
              'root',
              15000,
            );
          } else {
            // Refresh with no key → drop any stale copy, same semantics as the creds file rewrite.
            await execOneShot(sandboxWsIdCred, `rm -f ${apiKeyFile}`, 'root', 15000);
          }
        } catch {}
      }
      const result = {
        ...credResult,
        credentialValidation: validation.warning ? 'passed-with-warning' : 'passed',
      };
      if (sandboxWsIdCred) result.apiKeyInjected = Boolean(apiKey);
      if (apiKey) {
        result.apiKeyHint =
          'DevBridge API Key written to /tmp/hw_api_key (0600, kept separate from the temporary AK/SK in /tmp/hw_creds.sh — it is a long-lived account-level credential). At expose time the auth waterfall prefers the platform-injected keyring key (API_KEY_KEYRING), falls back to AK/SK, then to this file (API_KEY_FILE). Never echo the key into logs.';
      } else {
        result.apiKeyHint =
          'No DevBridge API Key provided locally — that is fine on recent sandbox images (hd-space-ai-shell line): the platform auto-injects the key into the sandbox keyring (HW_DEVBRIDGE_API_KEY via hwcloud) and the expose-time auth waterfall picks it up with zero user action. Only older sandboxes (created before the injection existed, image not upgradeable in place) need the one-time manual fallback: create an API Key at https://devstation.connect.huaweicloud.com/space/devbridge/apikey, set the local HW_API_KEY environment variable (preferred — keeps the key out of the conversation), and re-run this tool to inject it as /tmp/hw_api_key.';
      }
      if (validation.projectId) result.projectId = validation.projectId;
      if (validation.warning) result.warning = validation.warning;
      if (validation.skipped) result.warning = validation.error;
      return result;
    }
    case 'huaweicloud_voucher_status':
      return await hdkitVoucherStatus(args.domain_id);
    case 'huaweicloud_voucher_claim':
      return await hdkitVoucherClaim(args.domain_id);
    case 'huaweicloud_competition_voucher_claim':
      return await hdkitCompetitionVoucherClaim(args.domain_id);
    case 'huaweicloud_check_update':
      return await handleCheckUpdate(args, { sessionId: opts?.sessionId, doQuery: opts?.doQuery });
    case 'huaweicloud_upgrade':
      return await handleUpgrade(args, { sessionId: opts?.sessionId });
    case 'huaweicloud_obs_set_website_config':
      return await handleObsWebsiteConfig(args);
    case 'huaweicloud_obs_set_cors':
      return await handleObsCorsConfig(args);
    default:
      throw new Error(`Unknown tool: ${name}`);
  }
}

async function handleCheckUpdate(args = {}, opts = {}) {
  const { sessionId = null, doQuery } = opts;
  const current = readInstalledVersion() || '0.0.0';
  if (args.dismiss === true) {
    const distTags = await getUpdateDistTags(current, { sessionId, doQuery });
    if (!distTags) {
      // 查询失败：不降级为 current 冷却、不写 skip，返回 check_failed。
      // 不调 invalidateUpdateCache()，以保留 failedAt 的 5 分钟失败节流。
      return judgeUpdate(current, null, null);
    }
    const target = determineTarget(current, distTags);
    const dismissedVersion =
      typeof args.dismissVersion === 'string' && args.dismissVersion ? args.dismissVersion : target || current;
    const state = writeSkipState(resolveSkipFilePath(sessionId), dismissedVersion);
    invalidateUpdateCache();
    return judgeUpdate(current, distTags, state);
  }
  return getCachedUpdateInfo(current, { sessionId, doQuery });
}

async function handleUpgrade(args = {}, opts = {}) {
  const sessionId = opts?.sessionId || null;
  const target = typeof args.target === 'string' && args.target ? args.target : 'all';
  const version = typeof args.version === 'string' && args.version ? args.version : 'latest';
  const current = readInstalledVersion() || '0.0.0';
  const info = await getCachedUpdateInfo(current, { sessionId });
  if (info && info.result === 'up_to_date') {
    return {
      success: false,
      requiresRestart: false,
      message: '已是最新版本，无需升级。',
      currentVersion: info.currentVersion,
      targetVersion: info.targetVersion,
    };
  }
  return upgradePackage({ target, version });
}

function hookResult(result) {
  return {
    ok: result.decision !== 'deny',
    decision: result.decision,
    findings: result.findings,
    nextStep:
      result.decision === 'deny'
        ? 'Revise the command, artifact, or deployment plan before execution.'
        : result.decision === 'warn'
          ? 'Review the warnings with the user before proceeding.'
          : 'No Huawei Cloud hook risk rule matched.',
  };
}

export async function runVersionCheck(options = {}) {
  const result = probeHcloud(options);
  return {
    installed: result.installed,
    authenticated: result.ok && !/配置文件中不存在配置项|USE_ERROR.*配置/i.test(result.output || ''),
    errorCode: result.errorCode,
    status: result.status,
    output: result.output,
    kooCliVersion: result.requiredVersion || undefined,
    installedVersion: result.installedVersion || undefined,
    versionMismatch: Boolean(result.versionMismatch),
    nextStep: hcloudProbeNextStep(result),
    raw: hcloudProbeRaw(result),
    authHint:
      'If hcloud is installed but commands fail with "配置文件中不存在配置项", run `npx huaweicloud-devkit auth init` outside agent chat to configure credentials.',
  };
}

async function showProfileRedacted(profile) {
  const args = ['configure', 'show'];
  if (profile) {
    args.push('--cli-profile', String(profile));
  }
  const result = await runHcloud(args, { allowWrites: false, allowCredentialRead: true }).catch((error) => ({
    ok: false,
    blocked: true,
    reason: error.message,
  }));
  if (result.blocked) {
    return {
      ok: false,
      blockedByPolicy: true,
      reason: result.reason,
      safeAlternative:
        'Use huaweicloud_show_profile_redacted so profile output is returned through the redaction pipeline.',
    };
  }
  return {
    ok: result.ok,
    note: result.ok
      ? 'Profile information was returned through the toolkit redaction pipeline.'
      : 'Failed to retrieve profile — hcloud may not be installed or configured.',
    result: redactSecrets(result),
  };
}

async function setupObsConfig(profile) {
  const stored = readGlobalCredentials();
  if (stored?.ak && stored?.sk) {
    try {
      const obs = writeObsConfigFile(stored);
      return {
        ok: true,
        existed: false,
        created: true,
        path: obs.path,
        region: stored.region,
        endpoint: obs.endpoint,
        source: 'global-credentials',
        note: 'OBS credentials synced from the global credential vault. OBS commands (hcloud OBS ls, mb, cp, etc.) should now work.',
      };
    } catch (error) {
      return {
        ok: false,
        error: error.message,
        nextStep: 'Run "npx huaweicloud-devkit auth init" to refresh credentials and region.',
      };
    }
  }

  return setupObsConfigFromHcloud(profile);
}

async function setupObsConfigFromHcloud(profile) {
  const obsConfigPath = join(homedir(), '.obsutilconfig');
  if (existsSync(obsConfigPath)) {
    return {
      ok: true,
      existed: true,
      path: obsConfigPath,
      note: 'OBS config already exists. Delete ~/.obsutilconfig first if you need to re-sync.',
    };
  }

  const args = ['configure', 'show'];
  if (profile) args.push('--cli-profile', String(profile));
  const result = await runHcloud(args, { allowWrites: false, allowCredentialRead: true });

  if (!result.ok) {
    return {
      ok: false,
      error: 'Failed to read hcloud profile.',
      detail: result.error || result.stderr || 'hcloud not installed or not configured',
      nextStep: 'Run "npx huaweicloud-devkit auth init" outside agent chat, then retry.',
    };
  }

  let accessKeyId;
  let secretAccessKey;
  let region;

  try {
    const parsed = typeof result.stdout === 'string' ? JSON.parse(result.stdout) : result.stdout;
    const cred = parsed.currentCredential || {};
    accessKeyId = cred.accessKeyId || cred.ak || cred.access_key || '';
    secretAccessKey = cred.secretAccessKey || cred.sk || cred.secret_key || '';
    region = parsed.currentRegion || parsed.region || '';
  } catch {
    return {
      ok: false,
      error: 'Failed to parse hcloud profile output.',
      detail: 'hcloud configure show returned unexpected format',
    };
  }

  if (!accessKeyId || !secretAccessKey) {
    return {
      ok: false,
      error: 'No credentials found in hcloud profile.',
      nextStep: 'Run "npx huaweicloud-devkit auth init" outside agent chat to set up credentials first.',
    };
  }

  if (!region) {
    return {
      ok: false,
      error: 'No region found in hcloud profile.',
      nextStep: 'Run "npx huaweicloud-devkit auth init" outside agent chat to configure credentials and region.',
    };
  }

  const endpoint = `https://obs.${region}.myhuaweicloud.com`;
  // Flat key=value format (no [default] section) as written by KooCLI 7.x `hcloud OBS config`.
  const configContent = `endpoint=${endpoint}\nak=${accessKeyId}\nsk=${secretAccessKey}\n`;

  try {
    writeFileSync(obsConfigPath, configContent, { encoding: 'utf8', mode: 0o600 });
  } catch (error) {
    return {
      ok: false,
      error: 'Failed to write OBS config file.',
      detail: error.message,
      path: obsConfigPath,
    };
  }

  return {
    ok: true,
    existed: false,
    created: true,
    path: obsConfigPath,
    region,
    endpoint,
    note: 'OBS credentials synced from hcloud profile. OBS commands (hcloud OBS ls, mb, cp, etc.) should now work.',
  };
}

const SERVICE_EXAMPLES = {
  ECS: { list: 'ECS ListServersDetails', create: 'ECS CreateServers', show: 'IMS GlanceShowImage' },
  VPC: { list: 'VPC ListVpcs', create: 'VPC CreateVpc', show: 'VPC ShowVpc' },
  FUNCTIONGRAPH: {
    list: 'FunctionGraph ListFunctions',
    create: 'FunctionGraph CreateFunction',
    show: 'FunctionGraph ShowFunctionConfig',
  },
  APIG: { list: 'APIG ListInstancesV2', create: 'APIG CreateInstanceV2', show: 'APIG ShowDetailsOfInstanceV2' },
  OBS: { list: 'OBS ls', create: 'OBS mb obs://<bucket>', show: 'OBS stat obs://<bucket>/<key>' },
  RDS: { list: 'RDS ListInstances', create: 'RDS CreateInstance', show: 'RDS ShowInstance' },
  CES: { list: 'CES ListAlarms', create: 'CES CreateAlarm', show: 'CES ListMetrics' },
  GAUSSDB: { list: 'GaussDB ListInstances', create: 'GaussDB CreateInstance', show: 'GaussDB ShowInstance' },
  DDS: { list: 'DDS ListInstances', create: 'DDS CreateInstance', show: 'DDS ShowInstance' },
  DCS: { list: 'DCS ListInstances', create: 'DCS CreateInstance', show: 'DCS ShowInstance' },
};

// DMS and DEW are Huawei Cloud aggregate service names that do not exist as
// single KooCLI service identifiers. Each maps to real KooCLI sub-services.
const AGGREGATE_SERVICE_MAP = {
  DMS: ['Kafka', 'RabbitMQ', 'RocketMQ'],
  DEW: ['KMS', 'CSMS'],
};

// Identity-class notes per service. BSS leads: its operations are split between
// Customer-level APIs (work with a normal IAM user) and Partner-level APIs
// (only valid for a partner/dealer identity). Calling a Partner-level API with a
// customer credential returns APIGW.0301 even when AK/SK are perfectly valid —
// the common false-positive diagnosis is "cli-domain-id missing".
const SERVICE_IDENTITY_NOTES = {
  BSS: [
    {
      identity: 'Customer-level (normal IAM user)',
      apis: [
        'ShowCustomerAccountBalances',
        'ListCustomerBillsFeeRecords',
        'ListCustomerCouponChangeRecords',
        'ListResourceUsage',
        'ListCosts',
      ],
      note: 'Work with a normal IAM user that has BSS Administrator or Finance role.',
    },
    {
      identity: 'Partner-level (partner/dealer only)',
      apis: ['ListQuotaCoupons', 'ListSubCustomerCoupons', 'ListSubCustomerBillDetail'],
      note: 'APIGW.0301 here means the caller identity is not a partner — NOT bad AK/SK or a missing cli-domain-id.',
    },
  ],
};

async function listOperations(service, options = {}) {
  const serviceName = String(service || '').trim();
  if (!/^[A-Za-z][A-Za-z0-9-]{1,63}$/.test(serviceName)) {
    throw new Error('service must be a KooCLI service name such as ECS, VPC, IMS, OBS, RDS, or CDN.');
  }
  const upperName = serviceName.toUpperCase();
  const subServices = AGGREGATE_SERVICE_MAP[upperName];
  if (subServices && subServices.length) {
    const results = await Promise.all(
      subServices.map(async (sub) => {
        const r = await runHcloud([sub, '--help'], {
          timeoutMs: options.timeoutMs,
          maxRetries: 0,
        });
        let result = r;
        if (!result.ok) {
          result = await runHcloud([sub, 'help'], {
            timeoutMs: options.timeoutMs,
            maxRetries: 0,
          });
        }
        return {
          subService: sub,
          command: `hcloud ${sub} --help`,
          examples: SERVICE_EXAMPLES[sub.toUpperCase()] || {
            note: `No cached examples for ${sub}. Use the help text above to discover available operations.`,
          },
          result,
        };
      }),
    );
    return {
      service: serviceName,
      aggregate: true,
      aggregatedFrom: subServices,
      selectionRule:
        'DMS/DEW are aggregate service names. Use each sub-service help text below to select the exact KooCLI operation name.',
      identityNotes: SERVICE_IDENTITY_NOTES[upperName] || null,
      subServices: results,
    };
  }
  const isObs = /^obs$/i.test(serviceName);
  const svc = isObs ? 'obs' : serviceName;
  const args = isObs ? ['obs', 'help'] : [svc, '--help'];
  let result = await runHcloud(args, {
    timeoutMs: options.timeoutMs,
    maxRetries: 0,
  });
  if (!result.ok && !isObs) {
    result = await runHcloud([svc, 'help'], {
      timeoutMs: options.timeoutMs,
      maxRetries: 0,
    });
  }
  return {
    service: serviceName,
    command: isObs ? 'hcloud obs help' : `hcloud ${svc} --help`,
    selectionRule:
      'Use this help text to select the exact KooCLI operation name before planning any service command. After selecting an operation, run "hcloud <Service> <Operation> --help" to confirm exact parameter names before constructing the command.',
    identityNotes: SERVICE_IDENTITY_NOTES[upperName] || null,
    examples: SERVICE_EXAMPLES[upperName] || {
      note: `No cached examples for ${serviceName}. Use the help text above to discover available operations.`,
    },
    result,
  };
}

async function runApprovedCommand(args = {}) {
  if (args.approvedByUser !== true) {
    throw new Error('approvedByUser must be true after explicit user approval for this exact command.');
  }
  const token = String(args.approvalToken || '');

  // D4-24 precise JSON contract (#745): expired and already-consumed tokens
  // return a structured result instead of throwing a generic Error string, so
  // clients can machine-assert the two non-success states.
  const inspection = inspectApprovalToken(token);
  if (inspection.state === 'already_consumed') {
    return { status: 'ok', outcome: 'already_processed' };
  }
  if (inspection.state === 'expired') {
    return { status: 'rejected', code: 'CONFIRM_TOKEN_EXPIRED' };
  }
  if (inspection.state === 'not_found') {
    // A token that was never created (typo / unknown / pruned beyond the
    // tombstone window) is still a rejection, but carries no expired/already
    // semantics — surface a distinct code so clients can tell the cases apart.
    return { status: 'rejected', code: 'CONFIRM_TOKEN_NOT_FOUND' };
  }

  const stored = consumeApprovalToken(token);
  if (!stored) {
    // Defensive: inspectApprovalToken said 'valid' but consume returned null
    // (e.g. raced and pruned between the two reads). Re-classify so we never
    // return a misleading success.
    const recheck = inspectApprovalToken(token);
    if (recheck.state === 'expired') return { status: 'rejected', code: 'CONFIRM_TOKEN_EXPIRED' };
    if (recheck.state === 'already_consumed') return { status: 'ok', outcome: 'already_processed' };
    return { status: 'rejected', code: 'CONFIRM_TOKEN_NOT_FOUND' };
  }
  const providedArgs = Array.isArray(args.args) ? args.args.map(String) : [];
  if (hashArgs(providedArgs) !== stored.argsHash) {
    const redactedStored = JSON.stringify(stored.argsRedacted);
    const redactedProvided = JSON.stringify(redactSecrets(providedArgs));
    if (redactedStored !== redactedProvided) {
      throw new Error(
        'Provided args do not match the approved plan. Use the exact args from the plan. ' +
          'If the plan shows <redacted> for passwords or secrets, replace <redacted> with the actual values in approvedCommand.',
      );
    }
  }
  const strictPlan = planHcloudCommand(providedArgs, { allowWrites: false });
  const result = await runHcloud(providedArgs, {
    allowWrites: true,
    timeoutMs: args.timeoutMs,
    maxRetries: args.maxRetries,
    cwd: args.cwd,
    stdin: args.stdin,
  });
  result.approved = true;
  result.plan = strictPlan;
  return result;
}

function serviceCatalog(intent = '') {
  const it = String(intent).toLowerCase();
  const routeMap = [
    {
      keywords: [
        'ecs',
        'server',
        'vm',
        'instance',
        'compute',
        'flavor',
        'image',
        '弹性云服务器',
        '云服务器',
        '服务器',
        '虚拟机',
        '镜像',
      ],
      skills: ['huawei-ecs'],
      services: ['ECS'],
    },
    {
      keywords: [
        'vpc',
        'subnet',
        'network',
        'security group',
        'eip',
        'nat',
        'vpn',
        'bandwidth',
        '虚拟私有云',
        '子网',
        '网络',
        '安全组',
        '弹性公网IP',
        'NAT网关',
        'VPN网关',
        '带宽',
      ],
      skills: ['huawei-vpc'],
      services: ['VPC', 'EIP'],
    },
    {
      keywords: [
        'obs',
        'bucket',
        'storage',
        'object',
        'static website',
        'static site',
        'hosting',
        '对象存储',
        '存储桶',
        '桶',
        '存储',
        '对象',
        '静态网站',
        '静态托管',
      ],
      skills: ['huawei-obs'],
      services: ['OBS'],
    },
    {
      keywords: [
        'functiongraph',
        'serverless',
        'function',
        'lambda',
        'trigger',
        'faas',
        '函数工作流',
        '函数',
        '触发器',
        '无服务器',
        '函数计算',
      ],
      skills: ['huawei-functiongraph'],
      services: ['FunctionGraph'],
    },
    {
      keywords: ['cce', 'kubernetes', 'k8s', 'container', 'cluster', 'node pool', 'swr', 'docker', 'image registry'],
      skills: ['huawei-cce'],
      services: ['CCE', 'SWR'],
    },
    {
      keywords: ['apig', 'api gateway', 'publish', 'throttle', 'API网关', '限流'],
      skills: ['huawei-cloud-apig-instance-management'],
      services: ['APIG'],
    },
    {
      keywords: ['rds', 'mysql', 'postgresql', 'database', 'db', '关系型数据库', '数据库'],
      skills: ['huawei-rds'],
      services: ['RDS'],
    },
    {
      keywords: ['gaussdb', 'distributed', 'sharding', 'opengauss', '高斯数据库', '分布式数据库'],
      skills: ['huawei-cloud-gaussdb-instance-management'],
      services: ['GaussDB'],
    },
    {
      keywords: [
        'iam',
        'permission',
        'policy',
        'role',
        'user',
        'ak/sk',
        'access key',
        'agency',
        '身份认证',
        '身份管理',
        '权限',
        '策略',
        '角色',
        '用户',
        '访问密钥',
        '委托',
      ],
      skills: ['huawei-iam'],
      services: ['IAM'],
    },
    {
      keywords: [
        'dew',
        'secret',
        'kms',
        'encrypt',
        'decrypt',
        'certificate',
        'csms',
        '数据加密服务',
        '密钥管理',
        '密钥',
        '加密',
        '解密',
        '证书',
        '凭据管理',
      ],
      skills: ['huawei-cloud-dew-key-management'],
      services: ['CSMS', 'KMS'],
    },
    {
      keywords: ['modelarts', 'ai', 'model', 'training', 'inference', 'machine learning'],
      skills: ['huawei-modelarts'],
      services: ['ModelArts'],
    },
    {
      keywords: ['billing', 'cost', 'bill', 'budget', 'expense', 'bss', '计费', '费用', '账单', '预算', '开销'],
      skills: ['huawei-billing'],
      services: ['BSS'],
    },
    {
      keywords: ['waf', 'aad', 'ddos', 'firewall', 'web protection'],
      skills: ['huawei-cloud-waf-aad-rule-management'],
      services: ['WAF', 'AAD'],
    },
    {
      keywords: ['smn', 'dms', 'notification', 'message', 'kafka', 'rabbitmq'],
      skills: ['huawei-cloud-smn-dms-message'],
      services: ['SMN', 'DMS'],
    },
    {
      keywords: ['ces', 'monitor', 'alarm', 'metric', 'dashboard', 'cloud eye', '监控', '告警', '云监控'],
      skills: ['huawei-cloud-eye'],
      services: ['CES'],
    },
    {
      keywords: ['cts', 'audit', 'trace', 'tracker', '审计', '追踪'],
      skills: ['huawei-cloud-cts-trace-management'],
      services: ['CTS'],
    },
    {
      keywords: ['cbr', 'backup', 'restore', 'vault', 'snapshot', '备份', '恢复', '快照', '存储库'],
      skills: ['huawei-cbr'],
      services: ['CBR'],
    },
    {
      keywords: ['deployment', 'deploy', 'ci/cd', 'pipeline', 'release'],
      skills: ['huawei-cloud-deployment-task-management'],
      services: ['CloudDeploy'],
    },
    {
      keywords: [
        'sandbox',
        'devstation',
        'workspace',
        'terminal',
        'preview',
        'hwlink',
        'website',
        'web app',
        'webapp',
        'hosting',
        '网站',
        '网页',
        '静态',
      ],
      skills: ['huawei-sandbox'],
      services: ['Sandbox', 'DevStation'],
    },
    {
      keywords: [
        'dds',
        'dcs',
        'mongodb',
        'redis',
        'memcached',
        'cache',
        'document db',
        '文档数据库',
        '缓存',
        '内存数据库',
      ],
      skills: ['huawei-cloud-dds-dcs-instance-management'],
      services: ['DDS', 'DCS'],
    },
    {
      keywords: ['elb', 'load balancer', '负载均衡', '弹性负载均衡', '监听器', '证书'],
      skills: ['huawei-vpc'],
      services: ['ELB'],
    },
    {
      keywords: ['voucher', 'coupon', 'incentive', 'credit', '领券', '代金券', '优惠券', '激励金', '领取'],
      skills: ['huawei-voucher'],
      services: ['Incentive Voucher'],
    },
  ];
  const matched = [];
  const tokens = new Set(it.split(/[\s,./-]+/).filter((t) => t.length > 0));
  const cjk = /[\u4e00-\u9fff]/;
  for (const route of routeMap) {
    if (
      route.keywords.some((kw) => (kw.includes(' ') || cjk.test(kw) ? it.includes(kw.toLowerCase()) : tokens.has(kw)))
    ) {
      matched.push(route);
    }
  }
  const recommendedSkills = [...new Set(matched.flatMap((r) => r.skills))];
  const recommendedServices = [...new Set(matched.flatMap((r) => r.services))].slice(0, 5);

  // Deployment intent (deploy/host/publish a web app or static website) must never
  // default to a storage/other service — recommend the sandbox first.
  const deploymentIntent = /deploy|host|hosting|publish|website|web app|preview|部署|托管|发布|网站|网页/.test(it);
  if (deploymentIntent && recommendedSkills.includes('huawei-sandbox')) {
    const idx = recommendedSkills.indexOf('huawei-sandbox');
    recommendedSkills.splice(idx, 1);
    recommendedSkills.unshift('huawei-sandbox');
  }

  return {
    intent,
    recommendedSkills: recommendedSkills.length ? recommendedSkills : ['Use huaweicloud-core to route intent.'],
    recommendedServices: recommendedServices.length
      ? recommendedServices
      : ['Run hcloud --help to list available services.'],
    capabilityOrder: [
      'Huawei Cloud Skills for task-specific workflows and examples',
      'KooCLI hcloud for local authenticated operations and quick inspection',
      'Huawei Cloud API documentation for exact request and response contracts',
      'Huawei Cloud SDKs for application code integration',
      'Huawei Cloud MCP when an official or approved server is available',
      'Terraform Provider only when IaC reviewability and repeatability are important',
    ],
    ruleOfThumb: {
      skills: 'Start here when the user describes a scenario or wants a guided workflow.',
      cli: 'Use for local diagnostics, read-only inspection, and commands the user can review.',
      api: 'Use for exact service contract, region endpoint, project_id, pagination, and error codes.',
      sdk: 'Use when writing application code that calls Huawei Cloud services.',
      mcp: 'Prefer approved MCP tools when available because tools can carry structured schemas.',
      terraform: 'Keep low priority in V1; suggest it for reviewed infrastructure changes, not quick diagnosis.',
    },
  };
}

function explainError({ service = 'unknown', errorCode = '', message = '', requestId = '' } = {}) {
  const combined = `${errorCode} ${message}`.toLowerCase();
  const suggestions = [];
  const svc = String(service).toLowerCase();

  const SERVICE_ALIASES = {
    functiongraph: 'FSS',
    fgs: 'FSS',
    ecs: 'Ecs',
    ECS: 'Ecs',
    kps: 'Kps',
    KPS: 'Kps',
  };
  // #935 E2E-B1: real MCP calls pass only errorCode (e.g. Ecs.0019, KPS.9004)
  // with no service — derive the service key from the dotted-code prefix so the
  // service-keyed mapping table is hit. Explicit service behavior is unchanged.
  let resolvedService = service;
  if ((!service || svc === 'unknown') && /^[A-Za-z]+\.\w+/.test(errorCode)) {
    const prefix = errorCode.split('.')[0].toLowerCase();
    resolvedService = SERVICE_ALIASES[prefix] || errorCode.split('.')[0].toUpperCase();
  }
  const patternKey = SERVICE_ALIASES[svc] || resolvedService;

  const hwErrorPatterns = {
    OBS: {
      InvalidAccessKeyId:
        'OBS uses AK/SK directly (not IAM tokens). Verify AK/SK validity, OBS endpoint, and OBS permissions.',
      UserRestricted:
        'This IAM user is restricted from OBS operations (403). Check IAM console → Users → Permissions: grant OBS bucket/object actions, or use an unrestricted account. If the account is a sub-account, the main account may have imposed restrictions.',
    },
    APIG: {
      'APIC.7241': 'The enterprise_project_id is required for enterprise accounts. Add --enterprise_project_id=0.',
      'APIC.7242':
        'The EIP binding method depends on loadbalancer_provider. Use AddIngressEipV2 for elb, AddEipV2 for lvs.',
      'APIC.7256': 'Bandwidth minimum is 5 Mbps. Use --bandwidth_size=5 or higher.',
      'APIC.7310': 'available_zone_ids must use AZ codes (e.g. ap-southeast-3a), NOT UUIDs from ListAvailableZonesV2.',
    },
    FSS: {
      'FSS.0403':
        'Missing FunctionGraph IAM permissions. Attach FunctionGraph FullAccess role or grant specific actions.',
      'FSS.1078': '--code_filename is filename-only (no path). cd to the file directory before running the command.',
      'FSS.1417':
        'event_data field validation failed. Check parameter format: use dotted key=value, verify required hidden-optional fields.',
    },
    VPC: {
      'VPC.0301': 'Bandwidth name is required for PER type EIPs, even though --help marks it optional.',
    },
    Ecs: {
      'Ecs.0707':
        'The flavor + image-type combination does not exist ("the product does not exist") — the error does not say which side is wrong, so check BOTH (#922): (1) the flavor is abandoned/sellout in this region/AZ (check os_extra_specs.cond:operation:status and cond:operation:az; see the huawei-ecs skill references/flavors.md for the AZ-vs-global-status conflict rule); (2) the image TYPE is incompatible with the flavor — market-type images fail with KunPeng flavors (kc1/kc2 etc.). Fix: switch the image to a gold-type image or switch to a compatible general-purpose flavor (verified: kc2.small.2 + market Ubuntu → Ecs.0707; s6.medium.2 + gold Ubuntu works), re-listing with hcloud ECS ListFlavors / hcloud IMS ListImages --__imagetype=gold first.',
      // #935 (report 4 problem 1 / report 1 坑5): real-world ECS order failures
      // with no mapping — flavor offline, AZ capacity, balance, keypair restriction.
      'Ecs.0019':
        'The flavor has been taken offline (Ecs.0019). Run `hcloud ECS ListFlavors --cli-region=<region>` to query currently on-sale flavors and switch to a replacement flavor (see the huawei-ecs skill references/flavors.md for the cond:operation:status field rules — a flavor marked 卖光/下线 keeps failing until you pick an on-sale one), then recreate.',
      'Ecs.0319':
        'The requested flavor has insufficient capacity in the selected availability zone (Ecs.0319). Fix: retry in a different availability zone, or switch to a replacement flavor (list on-sale flavors with `hcloud ECS ListFlavors --cli-region=<region>`), then recreate.',
      'Ecs.0044':
        'The requested volume type is sold out in the selected availability zone (Ecs.0044, e.g. "the volumeType [SATA] is sellout in az[cn-north-4a]"). This is the ROOT VOLUME/DISK type being unavailable — a different failure from Ecs.0319 (flavor capacity). Fix: switch `--server.root_volume.volumetype` to an available type (SAS/SSD/GPSSD — query availability first) or retry in a different availability zone (`hcloud ECS NovaListAvailabilityZones --cli-region=<region>`). ListFlavors does NOT pre-warn about volume-type sellouts — you only find out at order time.',
      'Ecs.0067':
        'Order submission rejected for balance reasons (Ecs.0067). Check the cash balance with `hcloud BSS ShowCustomerAccountBalances --cli-region=cn-north-1` and top up if needed — pay-per-use order risk control checks the CASH balance only (代金券/vouchers do NOT participate in order risk control; they only offset the bill at settlement). Also settle any historical arrears, however small, before retrying.',
    },
    APIGW: {
      'APIGW.0301':
        'Incorrect IAM authentication information. The AK/SK is invalid (check the SK for typos), the security token is missing or expired, or the profile lacks project_id. Fix: re-run "npx huaweicloud-devkit auth init" (it auto-sets project_id), or set it manually: hcloud configure set --cli-project-id=<project_id> after finding it via hcloud IAM KeystoneListProjects --cli-region=<region> --name=<region>.',
      'APIGW.0802':
        'The current IAM user has no permissions in the requested region. Go to IAM console → Users → Permissions → add the target region, or switch to a different region.',
    },
    // #935 (report 1 坑5): KPS keypair creation has its own restriction code —
    // the Kps service had no entry at all, so the error fell through to generic advice.
    Kps: {
      'KPS.9004':
        'Keypair creation rejected for account restrictions (KPS.9004). Check the cash balance with `hcloud BSS ShowCustomerAccountBalances --cli-region=cn-north-1` and top up if needed, and settle any historical arrears (even a small unpaid amount triggers this) — then retry `hcloud ECS NovaCreateKeypair` or create the keypair in the console.',
    },
  };
  if (hwErrorPatterns[patternKey] && hwErrorPatterns[patternKey][errorCode]) {
    suggestions.push(hwErrorPatterns[patternKey][errorCode]);
  }
  const svcPatterns = hwErrorPatterns[patternKey] || {};
  for (const [code, tip] of Object.entries(svcPatterns)) {
    if (errorCode && code.includes(errorCode)) {
      if (!suggestions.includes(tip)) suggestions.push(tip);
    }
  }

  // G: when the active credential set is a temporary STS token that has already
  // expired, surface that as the primary cause before generic auth guidance.
  let activeCreds;
  try {
    activeCreds = resolveCredentialsWithRuntime({ allowMissing: true });
  } catch {
    activeCreds = null;
  }
  if (activeCreds?.ak && activeCreds?.sk && activeCreds.securityToken) {
    const expiry = parseStsExpiry({ securityToken: activeCreds.securityToken });
    if (expiry !== null && expiry <= Date.now()) {
      suggestions.push(
        'CREDENTIAL_EXPIRED: the temporary STS security token has expired. Re-authenticate to obtain fresh credentials (e.g. run "npx huaweicloud-devkit auth init" or re-login / restart the session).',
      );
    }
  }

  if (/auth|token|credential|ak|sk|401|403|unauthorized|forbidden|Incorrect IAM/i.test(combined)) {
    if (svc === 'obs') {
      suggestions.push(
        'OBS uses AK/SK directly, not IAM tokens. Verify AK/SK validity and OBS bucket permissions via hcloud configure list or the Huawei Cloud console.',
      );
    } else {
      suggestions.push('Check KooCLI profile, region, project_id, and IAM permissions without printing secrets.');
    }
  }
  if (/APIGW\.(\d+)/i.test(errorCode)) {
    suggestions.push(
      'APIGW.' +
        (errorCode.match(/APIGW\.(\d+)/i) || [])[1] +
        ': API Gateway layer error. ' +
        (errorCode === 'APIGW.0802'
          ? 'IAM user has no region permissions — check IAM console → User → Permissions → add target region.'
          : errorCode === 'APIGW.0301'
            ? 'Incorrect IAM authentication information — verify AK/SK (SK typos are the usual cause), security token expiry, and that project_id is configured (auth init auto-sets it).'
            : 'Verify the API request, region endpoint, and IAM permissions.'),
    );
  }
  if (/region|endpoint|project/i.test(combined)) {
    suggestions.push('Confirm the service endpoint, region, and project_id match the target resource.');
  }
  if (/quota|limit|insufficient|reach the limit/i.test(combined)) {
    suggestions.push(
      'Check quota and resource limits before retrying a create or scale operation. Consider switching accounts or requesting a quota increase.',
    );
  }
  if (/not.?found|404/i.test(combined)) {
    if (/list.?regions/i.test(svc)) {
      suggestions.push('Use hcloud IAM KeystoneListRegions (not list-regions).');
    } else {
      suggestions.push('List resources in the same region/project and verify the resource identifier.');
    }
  }
  if (!suggestions.length) {
    suggestions.push(
      'No known error-code pattern matched. Re-run the failing command with --debug to capture ' +
        'X-Request-Id from the response headers, then re-call explain_error with service, operation, ' +
        'region, the full redacted message, and requestId.',
    );
    if (errorCode) {
      suggestions.push(
        `Search the error code "${errorCode}" in the Huawei Cloud error center (support.huaweicloud.com) for the authoritative cause.`,
      );
    }
  }

  if (requestId) {
    suggestions.push('Provide the Request ID (' + requestId + ') when contacting Huawei Cloud support.');
  }

  const uniqueSuggestions = suggestions.filter((s, i, arr) => {
    return !arr.slice(0, i).some((prev) => prev.substring(0, 50).toLowerCase() === s.substring(0, 50).toLowerCase());
  });

  return {
    service,
    errorCode,
    requestId,
    suggestions: uniqueSuggestions,
  };
}

async function searchDocs(query, topic = 'all') {
  const q = String(query || '').toLowerCase();
  const tokens = q.split(/\s+/).filter((t) => t.length > 0);
  const results = [];
  try {
    if (existsSync(SKILLS_ROOT)) {
      const dirs = listSkillDirs(SKILLS_ROOT);
      for (const dir of dirs) {
        const skillPath = join(SKILLS_ROOT, dir, 'SKILL.md');
        if (!existsSync(skillPath)) continue;
        const content = readFileSync(skillPath, 'utf8');
        const frontmatter = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
        let description = '';
        let name = dir;
        if (frontmatter) {
          const fm = frontmatter[1];
          const nameMatch = fm.match(/^name:\s*(.+)$/m);
          if (nameMatch) name = nameMatch[1].trim();
          const descMatch = fm.match(/^description:\s*(.+)$/m);
          if (descMatch) description = descMatch[1].trim();
        }
        if (topic !== 'all') {
          const topicLower = topic.toLowerCase();
          if (!name.toLowerCase().includes(topicLower) && !description.toLowerCase().includes(topicLower)) continue;
        }
        const descLower = description.toLowerCase();
        const nameLower = name.toLowerCase();
        const contentLower = content.toLowerCase();
        const relevance = tokens.reduce((score, token) => {
          return (
            score +
            (descLower.includes(token) ? 3 : 0) +
            (nameLower.includes(token) ? 2 : 0) +
            (contentLower.includes(token) ? 1 : 0)
          );
        }, 0);
        if (relevance > 0) {
          results.push({
            source: 'skills/' + dir + '/SKILL.md',
            name,
            snippet: description.substring(0, 200),
            relevance,
          });
        }
      }
    }
  } catch (error) {
    return { ok: false, error: error.message, results: [] };
  }
  results.sort((a, b) => b.relevance - a.relevance);
  return { ok: true, query: q, topic, count: results.length, results: results.slice(0, 10) };
}

async function retrieveSkill(name) {
  const skillName = String(name || '').trim();
  if (!skillName) return { ok: false, error: 'Skill name is required.' };
  const skillPath = join(SKILLS_ROOT, skillName, 'SKILL.md');
  if (!existsSync(skillPath)) {
    const dirs = listSkillDirs(SKILLS_ROOT);
    return { ok: false, error: 'Skill "' + skillName + '" not found. Available: ' + dirs.join(', ') };
  }
  const content = readFileSync(skillPath, 'utf8');
  const references = [];
  const refDir = join(SKILLS_ROOT, skillName, 'references');
  if (existsSync(refDir)) {
    readdirSync(refDir).forEach((f) => {
      const refPath = join(refDir, f);
      references.push({ filename: f, content: readFileSync(refPath, 'utf8').substring(0, 4000) });
    });
  }
  const frontmatter = content.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  let version = 1,
    description = '';
  if (frontmatter) {
    const fm = frontmatter[1];
    const vm = fm.match(/^version:\s*(.+)$/m);
    if (vm) version = vm[1].trim();
    const dm = fm.match(/^description:\s*(.+)$/m);
    if (dm) description = dm[1].trim();
  }
  return { ok: true, name: skillName, version, description, content, references };
}

async function listRegions() {
  const result = await runHcloud(['IAM', 'KeystoneListRegions'], { timeoutMs: 30000, maxRetries: 0 }).catch(
    (error) => ({
      ok: false,
      error: error.message,
    }),
  );
  if (!result.ok) {
    return {
      ok: false,
      error: result.error || 'Failed to list regions.',
      fallback: 'Check https://developer.huaweicloud.com/endpoint for available regions.',
      staticRegions: [
        { id: 'cn-north-1', description: '华北-北京一' },
        { id: 'cn-north-4', description: '华北-北京四' },
        { id: 'cn-east-3', description: '华东-上海一' },
        { id: 'cn-east-2', description: '华东-上海二' },
        { id: 'cn-south-1', description: '华南-广州' },
        { id: 'ap-southeast-1', description: '香港' },
        { id: 'ap-southeast-3', description: '新加坡' },
        { id: 'ap-southeast-2', description: '曼谷' },
        { id: 'af-south-1', description: '约翰内斯堡' },
      ],
      note: 'hcloud unavailable. Showing static region list. For the complete list, visit the fallback URL.',
    };
  }
  let regions;
  try {
    const parsed = typeof result.stdout === 'string' ? JSON.parse(result.stdout) : result.stdout;
    const rawRegions = parsed.regions || [];
    regions = rawRegions.map((r) => ({
      id: r.id,
      description: r.description || r.names,
      type: r.type,
      locales: r.locales,
    }));
  } catch {
    regions = [{ raw: String(result.stdout).substring(0, 1000) }];
  }
  regions.sort((a, b) => String(a.id || '').localeCompare(String(b.id || '')));
  return { ok: true, count: regions.length, regions };
}

async function getRegionalAvailability(service, region) {
  const svc = String(service || '')
    .toLowerCase()
    .trim();
  const reg = String(region || '')
    .toLowerCase()
    .trim();
  if (!svc || !reg) return { ok: false, error: 'Both service and region are required.' };
  const known = {
    ecs: [
      'cn-south-1',
      'cn-north-4',
      'cn-north-1',
      'cn-east-3',
      'cn-east-2',
      'ap-southeast-3',
      'ap-southeast-2',
      'ap-southeast-1',
      'ap-southeast-4',
      'af-south-1',
      'tr-west-1',
      'sa-brazil-1',
      'la-north-2',
      'na-mexico-1',
      'me-east-1',
    ],
    obs: [
      'cn-south-1',
      'cn-north-4',
      'cn-north-1',
      'cn-east-3',
      'cn-east-2',
      'ap-southeast-3',
      'ap-southeast-2',
      'ap-southeast-1',
      'af-south-1',
    ],
    vpc: [
      'cn-south-1',
      'cn-north-4',
      'cn-north-1',
      'cn-east-3',
      'cn-east-2',
      'ap-southeast-3',
      'ap-southeast-2',
      'ap-southeast-1',
      'ap-southeast-4',
      'af-south-1',
      'tr-west-1',
      'sa-brazil-1',
      'la-north-2',
      'me-east-1',
    ],
    iam: ['global'],
    rds: [
      'cn-south-1',
      'cn-north-4',
      'cn-north-1',
      'cn-east-3',
      'cn-east-2',
      'ap-southeast-3',
      'ap-southeast-2',
      'ap-southeast-1',
    ],
    gaussdb: ['cn-south-1', 'cn-north-4', 'cn-east-3'],
    cce: [
      'cn-south-1',
      'cn-north-4',
      'cn-north-1',
      'cn-east-3',
      'cn-east-2',
      'ap-southeast-3',
      'ap-southeast-2',
      'ap-southeast-1',
    ],
    modelarts: ['cn-south-1', 'cn-north-4', 'cn-east-3'],
    functiongraph: [
      'cn-south-1',
      'cn-north-4',
      'cn-north-1',
      'cn-east-3',
      'cn-east-2',
      'ap-southeast-3',
      'ap-southeast-2',
      'ap-southeast-1',
    ],
    dew: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    smn: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    ces: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    cts: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    apig: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    cbr: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    dds: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
    dcs: ['cn-south-1', 'cn-north-4', 'cn-east-3', 'ap-southeast-3'],
  };
  if (!known[svc])
    return {
      ok: false,
      service: svc,
      region: reg,
      available: false,
      note:
        'Service ' +
        svc +
        ' is not in the regional availability cache. Run hcloud ' +
        svc.toUpperCase() +
        ' --help to verify, or check https://developer.huaweicloud.com/endpoint.',
    };
  const available = known[svc].includes(reg) || known[svc].includes('global');
  return {
    ok: true,
    service: svc,
    region: reg,
    available,
    note: available
      ? svc + ' is available in ' + reg + '.'
      : svc +
        ' availability in ' +
        reg +
        ' could not be confirmed. Verify at https://developer.huaweicloud.com/endpoint.',
    sourcedFrom: 'static cache, update via npm package upgrade',
    disclaimer:
      'This result reflects service-level availability only. It does NOT guarantee that your IAM user has permissions in this region. Account-level restrictions (e.g., APIGW.0802) may block actual API calls even when the service is available.',
  };
}

export function classifyRawCommand(command) {
  return classifyTextCommand(command);
}

// ── OBS Static Website Hosting (AWS4 signed REST API) ──

async function handleObsWebsiteConfig(args) {
  const { action, bucket, region, indexDocument, errorDocument } = args;
  if (!bucket || !region) {
    throw new Error('bucket and region are required');
  }
  const creds = resolveCredentialsWithRuntime({});
  if (!creds?.ak || !creds?.sk) {
    throw new Error('OBS website config requires AK/SK credentials. Run huaweicloud_auth_init first.');
  }

  const host = `${bucket}.obs.${region}.myhuaweicloud.com`;
  const endpoint = `https://${host}`;

  if (action === 'get') {
    const res = await obsSignedRequest('GET', endpoint, '/?website', '', creds, region);
    return { ok: res.status === 200, status: res.status, body: res.body };
  }

  if (action === 'delete') {
    const res = await obsSignedRequest('DELETE', endpoint, '/?website', '', creds, region);
    return { ok: res.status === 204, status: res.status };
  }

  if (action === 'set') {
    if (!indexDocument) {
      throw new Error('indexDocument is required for action=set');
    }
    const xmlParts = ['<WebsiteConfiguration>', `  <IndexDocument><Suffix>${indexDocument}</Suffix></IndexDocument>`];
    if (errorDocument) {
      xmlParts.push(`  <ErrorDocument><Key>${errorDocument}</Key></ErrorDocument>`);
    }
    xmlParts.push('</WebsiteConfiguration>');
    const body = xmlParts.join('\n');
    const res = await obsSignedRequest('PUT', endpoint, '/?website', body, creds, region);
    const websiteUrl = `http://${bucket}.obs-website.${region}.myhuaweicloud.com`;
    return {
      ok: res.status === 200,
      status: res.status,
      websiteUrl,
      message:
        res.status === 200
          ? `Static website hosting configured. Website URL: ${websiteUrl} (may take ~1 min to propagate)`
          : `Failed to configure website: HTTP ${res.status}`,
    };
  }

  throw new Error(`Unknown action: ${action}. Use set, get, or delete.`);
}

// #1003: same-structure extension of handleObsWebsiteConfig — KooCLI OBS does
// not expose a cors subcommand and there is no SetBucketCors MCP path, so
// agents fell back to installing a Python SDK in the sandbox just to configure
// CORS. This reuses obsSignedRequest (AWS4, s3 service) against /?cors.
async function handleObsCorsConfig(args = {}) {
  const { action, bucket, region, rules } = args;
  if (!bucket || !region) {
    throw new Error('bucket and region are required');
  }
  const creds = resolveCredentialsWithRuntime({});
  if (!creds?.ak || !creds?.sk) {
    throw new Error('OBS CORS config requires AK/SK credentials. Run huaweicloud_auth_init first.');
  }

  const host = `${bucket}.obs.${region}.myhuaweicloud.com`;
  const endpoint = `https://${host}`;
  const preflightHint =
    'Verify with an OPTIONS preflight before declaring success: ' +
    `curl -i -X OPTIONS --noproxy '*' 'https://${host}/<object-key>' -H 'Origin: <your-app-origin>' -H 'Access-Control-Request-Method: HEAD' ` +
    'must return HTTP 200 with an Access-Control-Allow-Origin header (200 without CORS headers = config not effective; ' +
    '403 = rule missing the requested method). See the huawei-obs skill common-pitfalls.md p05.';

  if (action === 'get') {
    const res = await obsSignedRequest('GET', endpoint, '/?cors', '', creds, region, 'cors');
    return { ok: res.status === 200, status: res.status, rules: res.body, verify: preflightHint };
  }

  if (action === 'delete') {
    const res = await obsSignedRequest('DELETE', endpoint, '/?cors', '', creds, region, 'cors');
    return { ok: res.status === 204, status: res.status };
  }

  if (action === 'set') {
    if (!Array.isArray(rules) || rules.length === 0) {
      throw new Error('rules array is required for action=set (allowedOrigin + allowedMethod, HEAD included)');
    }
    for (const rule of rules) {
      if (!rule?.allowedOrigin || !Array.isArray(rule?.allowedMethod) || rule.allowedMethod.length === 0) {
        throw new Error('each CORS rule needs allowedOrigin and a non-empty allowedMethod array');
      }
      if (!rule.allowedMethod.includes('HEAD')) {
        // p01: the BrowserJS SDK's HEAD ?apiversion probe gets swallowed by the
        // browser when HEAD is missing — the exact failure this tool exists to
        // prevent, so reject it at the input boundary instead of at runtime.
        throw new Error(
          "allowedMethod must include 'HEAD' — the BrowserJS SDK sends a HEAD ?apiversion probe before every " +
            'operation, and a CORS rule without HEAD makes the browser swallow it as Network Error (p01).',
        );
      }
    }
    const escapeXml = (s) =>
      String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const xmlParts = ['<CORSConfiguration>'];
    for (const rule of rules) {
      xmlParts.push('  <CORSRule>');
      xmlParts.push(`    <AllowedOrigin>${escapeXml(rule.allowedOrigin)}</AllowedOrigin>`);
      for (const method of rule.allowedMethod) {
        xmlParts.push(`    <AllowedMethod>${escapeXml(method)}</AllowedMethod>`);
      }
      for (const header of rule.allowedHeader || ['*']) {
        xmlParts.push(`    <AllowedHeader>${escapeXml(header)}</AllowedHeader>`);
      }
      if (rule.maxAgeSeconds != null) {
        xmlParts.push(`    <MaxAgeSeconds>${Number(rule.maxAgeSeconds)}</MaxAgeSeconds>`);
      }
      xmlParts.push('  </CORSRule>');
    }
    xmlParts.push('</CORSConfiguration>');
    const body = xmlParts.join('\n');
    const res = await obsSignedRequest('PUT', endpoint, '/?cors', body, creds, region, 'cors');
    return {
      ok: res.status === 200,
      status: res.status,
      message:
        res.status === 200
          ? `CORS configured for ${bucket} (${rules.length} rule(s)).`
          : `Failed to configure CORS: HTTP ${res.status}`,
      verify: preflightHint,
    };
  }

  throw new Error(`Unknown action: ${action}. Use set, get, or delete.`);
}

// Single AWS4-signed OBS REST API caller shared by the website/CORS tools
// (#1003): subresource is the bucket subresource being addressed — 'website'
// for PUT/GET/DELETE /?website, 'cors' for /?cors. Credential scope uses the
// s3 service name (OBS is S3-compatible).
async function obsSignedRequest(method, endpoint, pathAndQuery, body, creds, region, subresource = 'website') {
  const now = new Date();
  const dateStamp = now.toISOString().slice(0, 10).replace(/-/g, '');
  const amzDate = dateStamp + 'T' + now.toISOString().slice(11, 19).replace(/:/g, '') + 'Z';
  const payloadHash = createHash('sha256').update(body).digest('hex');

  const url = new URL(endpoint + pathAndQuery);
  const canonicalUri = '/';
  const canonicalQueryString = `${subresource}=`;
  const canonicalHeaders = `host:${url.host}\n` + `x-amz-content-sha256:${payloadHash}\n` + `x-amz-date:${amzDate}\n`;
  const signedHeaders = 'host;x-amz-content-sha256;x-amz-date';
  const canonicalRequest = [
    method,
    canonicalUri,
    canonicalQueryString,
    canonicalHeaders,
    signedHeaders,
    payloadHash,
  ].join('\n');

  const credentialScope = `${dateStamp}/${region}/s3/aws4_request`;
  const stringToSign = [
    'AWS4-HMAC-SHA256',
    amzDate,
    credentialScope,
    createHash('sha256').update(canonicalRequest).digest('hex'),
  ].join('\n');

  const kDate = createHmac('sha256', 'AWS4' + creds.sk)
    .update(dateStamp)
    .digest();
  const kRegion = createHmac('sha256', kDate).update(region).digest();
  const kService = createHmac('sha256', kRegion).update('s3').digest();
  const kSigning = createHmac('sha256', kService).update('aws4_request').digest();
  const signature = createHmac('sha256', kSigning).update(stringToSign).digest('hex');

  const authorization =
    `AWS4-HMAC-SHA256 Credential=${creds.ak}/${credentialScope}, ` +
    `SignedHeaders=${signedHeaders}, Signature=${signature}`;

  const headers = {
    Host: url.host,
    'x-amz-content-sha256': payloadHash,
    'x-amz-date': amzDate,
    Authorization: authorization,
  };
  if (body) headers['Content-Type'] = 'application/xml';
  if (creds.securityToken) headers['x-amz-security-token'] = creds.securityToken;

  const res = await fetchWithProxy(endpoint + pathAndQuery, {
    method,
    headers,
    body: body || undefined,
  });
  const resBody = await res.text();
  return { status: res.status, body: resBody };
}
