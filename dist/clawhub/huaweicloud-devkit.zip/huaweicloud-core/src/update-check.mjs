// Version-update detection & auto-upgrade for huaweicloud-devkit (session-level).
// Spec: docs/superpowers/specs/2026-09-07-version-upgrade-design.md (internal, not committed).
import { existsSync, readFileSync, writeFileSync, renameSync, mkdirSync, rmSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { join, dirname, resolve } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';

import { fetchWithProxy } from './proxy/proxy-agent.mjs';
import { SUPPORTED_AGENT_TARGETS } from './auth/agent-registration.mjs';

const IS_WINDOWS = process.platform === 'win32';
const NPM_BIN = IS_WINDOWS ? 'npm.cmd' : 'npm';
const NPX_BIN = IS_WINDOWS ? 'npx.cmd' : 'npx';
const TTL_MS = 60 * 60 * 1000;
const FAIL_THROTTLE_MS = 5 * 60 * 1000;
const COOLDOWN_DAYS = 3;

export function semverParse(input) {
  const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(input).trim());
  if (!m) return null;
  const pre = m[4] ? m[4].split('.') : null;
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]), pre, raw: String(input).trim() };
}

function comparePre(a, b) {
  if (a === null && b === null) return 0;
  if (a === null) return 1; // 无 prerelease（正式版）更大
  if (b === null) return -1;
  const length = Math.max(a.length, b.length);
  for (let i = 0; i < length; i++) {
    const x = a[i];
    const y = b[i];
    if (x === undefined) return -1;
    if (y === undefined) return 1;
    const xNum = /^\d+$/.test(x);
    const yNum = /^\d+$/.test(y);
    if (xNum && yNum) {
      const dx = Number(x);
      const dy = Number(y);
      if (dx !== dy) return dx < dy ? -1 : 1;
    } else if (xNum) {
      return -1; // 数字标识符 < 字母标识符
    } else if (yNum) {
      return 1;
    } else if (x !== y) {
      return x < y ? -1 : 1;
    }
  }
  return 0;
}

export function semverCompare(a, b) {
  const A = semverParse(a);
  const B = semverParse(b);
  if (!A || !B) {
    const sa = String(a);
    const sb = String(b);
    return sa === sb ? 0 : sa < sb ? -1 : 1;
  }
  if (A.major !== B.major) return A.major < B.major ? -1 : 1;
  if (A.minor !== B.minor) return A.minor < B.minor ? -1 : 1;
  if (A.patch !== B.patch) return A.patch < B.patch ? -1 : 1;
  return comparePre(A.pre, B.pre);
}

export function hasPrerelease(v) {
  const parsed = semverParse(v);
  return Boolean(parsed && parsed.pre);
}

export function determineTarget(current, distTags = {}) {
  const isPre = hasPrerelease(current);
  const candidates = [];
  if (distTags.latest) candidates.push(distTags.latest);
  if (isPre && distTags.next) candidates.push(distTags.next);
  if (!candidates.length) return null;
  return candidates.slice().sort(semverCompare).pop();
}

export function parseDistTagsOutput(stdout) {
  try {
    const text = String(stdout || '').trim();
    if (!text) return null; // 空输出视为 npm view 失败
    const parsed = JSON.parse(text);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    return {
      latest: typeof parsed.latest === 'string' ? parsed.latest : null,
      next: typeof parsed.next === 'string' ? parsed.next : null,
    };
  } catch {
    return null;
  }
}

function buildResult(current, distTags, extra = {}) {
  const result = {
    currentVersion: current,
    latestStable: distTags?.latest ?? null,
    latestNext: distTags?.next ?? null,
    targetVersion: extra.target ?? null,
    updateAvailable: extra.result === 'update_available',
    dismissed: extra.result === 'dismissed',
    dismissExpiresAt: extra.dismissExpiresAt ?? null,
    result: extra.result ?? 'up_to_date',
  };
  if (extra.note) result.note = extra.note;
  return result;
}

export function judgeUpdate(current, distTags, skipState, now = Date.now()) {
  if (process.env.HUAWEICLOUD_DEVKIT_SKIP_UPDATE === '1') {
    return buildResult(current, distTags ?? null);
  }
  if (!distTags) {
    return buildResult(current, null, { result: 'check_failed', note: '检测失败，不影响使用' });
  }
  // truthy 但无有效版本（如 failure 折叠后的 { latest:null, next:null }）同样视为检测失败
  if (!distTags.latest && !distTags.next) {
    return buildResult(current, null, { result: 'check_failed', note: '检测失败，不影响使用' });
  }
  const target = determineTarget(current, distTags);
  if (!target || semverCompare(target, current) <= 0) {
    return buildResult(current, distTags, { result: 'up_to_date', target: target ?? null });
  }
  const expiresAt = skipState?.expireAt ? new Date(skipState.expireAt).getTime() : 0;
  const inCooldown =
    Boolean(skipState) && now < expiresAt && semverCompare(target, String(skipState.dismissedVersion)) <= 0;
  if (inCooldown) {
    return buildResult(current, distTags, { result: 'dismissed', target, dismissExpiresAt: skipState.expireAt });
  }
  return buildResult(current, distTags, { result: 'update_available', target });
}

function selfDir() {
  return dirname(fileURLToPath(import.meta.url));
}

// Plugin manifests also carry the version and are kept in sync with package.json
// by `npm run validate`. Codex marketplace installs (`.codex/plugins/cache/...`)
// contain only the plugin directory — no package.json — so fall back to these
// manifests when neither candidate package.json exists (#576).
// The auto-upgrade snapshot backs these up and restores them on rollback so a
// failed update can never leave "new version in manifests + old src" behind (#1117).
export const VERSION_MANIFEST_RELS = [
  '.codex-plugin/plugin.json',
  '.claude-plugin/plugin.json',
  '.cursor-plugin/plugin.json',
  '.workbuddy-plugin/plugin.json',
  '.hermes-plugin/plugin.json',
  'openclaw.plugin.json',
];

export function readInstalledVersion() {
  const pluginRoot = resolve(selfDir(), '..');
  const packageRoot = resolve(pluginRoot, '..', '..');
  for (const base of [pluginRoot, packageRoot]) {
    try {
      const version = JSON.parse(readFileSync(join(base, 'package.json'), 'utf8')).version;
      if (typeof version === 'string' && version) return version;
    } catch {}
  }
  for (const rel of VERSION_MANIFEST_RELS) {
    try {
      const version = JSON.parse(readFileSync(join(pluginRoot, rel), 'utf8')).version;
      if (typeof version === 'string' && version) return version;
    } catch {}
  }
  return null;
}

// The version this MCP process started with. Frozen on first use so an
// auto-upgrade that replaces package.json on disk cannot make the running
// (old-code) process advertise the new version and slip past the server gate.
let runtimeVersion = null;
export function getRuntimeVersion() {
  if (runtimeVersion === null) runtimeVersion = readInstalledVersion() || '0.0.0';
  return runtimeVersion;
}

export function skipFilePath() {
  return join(resolve(selfDir(), '..'), '.update-skip.json');
}

export function fallbackSkipFilePath() {
  const base = process.env.HUAWEICLOUD_HOME || homedir();
  return join(base, '.config', 'huaweicloud', 'devkit-skip.json');
}

// 会话化 skip 文件：remote 多会话按 sessionId 拆分，stdio/默认保持原文件(向后兼容)。
function sanitizeSessionId(sessionId) {
  return String(sessionId || '').replace(/[^0-9a-zA-Z-]/g, '_');
}

// A1 定稿: 标准 agent 用插件目录副本(有 package.json); codex 等无副本时回退共享文件
export function resolveSkipFilePath(sessionId = null) {
  let base;
  try {
    if (existsSync(join(dirname(skipFilePath()), 'package.json'))) {
      base = skipFilePath();
    } else {
      base = fallbackSkipFilePath();
    }
  } catch {
    base = fallbackSkipFilePath();
  }
  // stdio / 默认 / 无 session → 原文件（保持向后兼容）
  if (!sessionId || sessionId === 'default' || sessionId === 'stdin') return base;
  return `${base}.${sanitizeSessionId(sessionId)}`;
}

export function readSkipState(file) {
  if (!existsSync(file)) return null;
  try {
    const parsed = JSON.parse(readFileSync(file, 'utf8'));
    if (!parsed || typeof parsed.dismissedVersion !== 'string' || !parsed.dismissedAt || !parsed.expireAt) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function writeSkipState(file, dismissedVersion, { at = Date.now(), days = COOLDOWN_DAYS } = {}) {
  const state = {
    dismissedVersion: String(dismissedVersion),
    dismissedAt: new Date(at).toISOString(),
    expireAt: new Date(at + days * 24 * 60 * 60 * 1000).toISOString(),
  };
  mkdirSync(dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
  try {
    renameSync(tmp, file);
  } catch (error) {
    rmSync(tmp, { force: true });
    throw error;
  }
  return state;
}

function debugLog(message) {
  if (process.env.HUAWEICLOUD_DEVKIT_DEBUG === '1' || process.env.HUAWEICLOUD_DEVKIT_DEBUG === 'true') {
    console.error(`[debug] ${message}`);
  }
}

function registryBase() {
  let registry = 'https://registry.npmjs.org';
  if (process.env.HUAWEICLOUD_NPM_REGISTRY) {
    registry = process.env.HUAWEICLOUD_NPM_REGISTRY.replace(/\/+$/, '');
  }
  return registry;
}

export function queryDistTagsFetch({ timeoutMs = 15000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetchWithProxy(`${registryBase()}/-/package/huaweicloud-devkit/dist-tags`)
    .then((resp) => {
      clearTimeout(timer);
      if (!resp || !resp.ok) return null;
      return resp.json().catch(() => null);
    })
    .catch((error) => {
      clearTimeout(timer);
      debugLog(`queryDistTagsFetch: ${error?.message || error}`);
      return null;
    });
}

const PUBLISH_TTL_MS = 6 * 60 * 60 * 1000;
const PUBLISH_FAIL_THROTTLE_MS = 5 * 60 * 1000;
let cachedPublishTimes = null;
let cachedPublishAt = 0;
let publishFailedAt = 0;

function publishCachePath(env = process.env) {
  const base = env.HUAWEICLOUD_HOME || homedir();
  return join(base, '.config', 'huaweicloud', 'devkit-registry-meta.json');
}

function readPublishDisk(now, env) {
  try {
    const parsed = JSON.parse(readFileSync(publishCachePath(env), 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    if (!parsed.time || typeof parsed.time !== 'object' || Array.isArray(parsed.time)) return null;
    if (!Number.isFinite(parsed.fetchedAt) || now - parsed.fetchedAt > PUBLISH_TTL_MS) return null;
    return parsed.time;
  } catch {
    return null;
  }
}

function writePublishDisk(times, now, env) {
  try {
    const target = publishCachePath(env);
    mkdirSync(dirname(target), { recursive: true, mode: 0o700 });
    const tmp = `${target}.${process.pid}.${Date.now()}.tmp`;
    writeFileSync(tmp, JSON.stringify({ fetchedAt: now, time: times }), { encoding: 'utf8', mode: 0o600 });
    renameSync(tmp, target);
  } catch {}
}

export function invalidatePublishTimeCache({ env = process.env } = {}) {
  cachedPublishTimes = null;
  cachedPublishAt = 0;
  publishFailedAt = 0;
  try {
    rmSync(publishCachePath(env), { force: true });
  } catch {}
}

// The registry packument carries the per-version publish timestamps used by
// the 24h auto-upgrade cooldown. The dist-tags endpoint does not, so this is a
// separate (cached) fetch. A missing timestamp is a fail-closed skip for the
// ordinary path; the forced path does not need it.
export async function queryPublishTimes({ timeoutMs = 15000, doFetch = fetchWithProxy } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const resp = await doFetch(`${registryBase()}/huaweicloud-devkit`, {
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });
    if (!resp || !resp.ok) return null;
    const data = await resp.json().catch(() => null);
    if (!data || typeof data !== 'object' || Array.isArray(data)) return null;
    return data.time && typeof data.time === 'object' && !Array.isArray(data.time) ? data.time : null;
  } catch (error) {
    debugLog(`queryPublishTimes: ${error?.message || error}`);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

export async function getVersionPublishTime(
  version,
  { now = Date.now(), timeoutMs = 15000, doFetch = fetchWithProxy, env = process.env } = {},
) {
  if (cachedPublishTimes && now - cachedPublishAt <= PUBLISH_TTL_MS) {
    return parsePublishTime(cachedPublishTimes[version]);
  }
  if (!cachedPublishTimes) {
    const disk = readPublishDisk(now, env);
    if (disk) {
      cachedPublishTimes = disk;
      cachedPublishAt = now;
      return parsePublishTime(disk[version]);
    }
  }
  if (!cachedPublishTimes && now - publishFailedAt < PUBLISH_FAIL_THROTTLE_MS) return null;
  const times = await queryPublishTimes({ timeoutMs, doFetch });
  if (!times) {
    publishFailedAt = now;
    return null;
  }
  cachedPublishTimes = times;
  cachedPublishAt = now;
  writePublishDisk(times, now, env);
  return parsePublishTime(times[version]);
}

function parsePublishTime(value) {
  if (typeof value !== 'string' || !value) return null;
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? ms : null;
}

export function queryDistTagsSync({ timeoutMs = 15000, cwd } = {}) {
  try {
    const result = spawnSync(NPM_BIN, ['view', 'huaweicloud-devkit', 'dist-tags', '--json'], {
      encoding: 'utf8',
      timeout: timeoutMs,
      windowsHide: true,
      cwd,
      // Windows + Node 22: spawning `npm.cmd` directly throws EINVAL (CVE-2024-27980
      // mitigation); shell:true routes the .cmd through cmd.exe like other spawns (#643).
      shell: true,
    });
    if (result.status !== 0) {
      debugLog(`queryDistTagsSync: npm view exited with status ${result.status}`);
      return null;
    }
    return parseDistTagsOutput(result.stdout);
  } catch (error) {
    debugLog(`queryDistTagsSync: ${error?.message || error}`);
    return null;
  }
}

export function queryDistTags({ timeoutMs = 15000, cwd } = {}) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(NPM_BIN, ['view', 'huaweicloud-devkit', 'dist-tags', '--json'], {
        windowsHide: true,
        cwd,
        shell: true,
      });
    } catch (error) {
      debugLog(`queryDistTags: ${error?.message || error}`);
      resolve(null);
      return;
    }
    const timer = setTimeout(() => {
      try {
        child.kill();
      } catch {}
      debugLog(`queryDistTags: timed out after ${timeoutMs}ms`);
      resolve(null);
    }, timeoutMs);
    let stdout = '';
    child.stdout.on('data', (d) => {
      stdout += String(d);
    });
    child.on('error', (error) => {
      clearTimeout(timer);
      debugLog(`queryDistTags: ${error?.message || error}`);
      resolve(null);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) {
        resolve(parseDistTagsOutput(stdout));
      } else {
        debugLog(`queryDistTags: npm view exited with code ${code}`);
        resolve(null);
      }
    });
  });
}

let cachedDistTags = null;
let cachedAt = 0;
let failedAt = 0;
let inflightQuery = null;
let lastHint = null;

export function invalidateUpdateCache() {
  cachedDistTags = null;
  cachedAt = 0;
  failedAt = 0;
  inflightQuery = null;
  lastHint = null;
}

function cacheValid(now = Date.now()) {
  return Boolean(cachedDistTags) && now - cachedAt <= TTL_MS;
}

export async function getCachedUpdateInfo(
  current,
  { doQuery = queryDistTags, now = Date.now(), sessionId = null } = {},
) {
  if (process.env.HUAWEICLOUD_DEVKIT_SKIP_UPDATE === '1') {
    lastHint = judgeUpdate(current, null, undefined, now);
    return lastHint;
  }
  const skipState = readSkipState(resolveSkipFilePath(sessionId));
  if (!cacheValid(now)) {
    if (!cachedDistTags && now - failedAt < FAIL_THROTTLE_MS) {
      lastHint = judgeUpdate(current, null, skipState, now);
      return lastHint;
    }
    if (!inflightQuery) {
      inflightQuery = doQuery()
        .then((distTags) => {
          if (distTags) {
            cachedDistTags = distTags;
            cachedAt = now;
          } else {
            failedAt = now;
          }
          return distTags;
        })
        .finally(() => {
          inflightQuery = null;
        });
    }
    const distTags = await inflightQuery;
    lastHint = judgeUpdate(current, distTags, skipState, now);
    return lastHint;
  }
  lastHint = judgeUpdate(current, cachedDistTags, skipState);
  return lastHint;
}

export function peekCachedUpdateInfo() {
  return lastHint && lastHint.updateAvailable && lastHint.targetVersion ? lastHint : null;
}

export async function getUpdateDistTags(current, { sessionId = null, doQuery } = {}) {
  const result = await getCachedUpdateInfo(current, { sessionId, doQuery });
  if (!result || result.result === 'check_failed') return null;
  return { latest: result.latestStable ?? null, next: result.latestNext ?? null };
}

export function applyUpdateHint(result, name, hint) {
  if (!hint || !hint.updateAvailable || !hint.targetVersion) return result;
  if (name === 'huaweicloud_check_update' || name === 'huaweicloud_upgrade') return result;
  return {
    ...result,
    _updateInfo: { currentVersion: hint.currentVersion, latestVersion: hint.targetVersion },
  };
}

function defaultSpawn(command, args, options) {
  return spawnSync(command, args, options);
}

// npm writes diagnostics as `npm error ...` lines; engine/platform noise as
// `npm warn ...`. Taking the raw last lines reports the warnings as the
// failure reason (observed: "npm warn EBADENGINE ..." twice) and truncates the
// real error, so prefer npm-error lines and drop the noise (#1117).
export function extractNpmFailureReason(execResult) {
  if (execResult?.error?.message) return execResult.error.message;
  const lines = String(execResult?.stderr || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const errorLines = lines.filter((line) => /^npm error/i.test(line));
  const isNoise = (line) =>
    /^npm warn/i.test(line) ||
    /^\(node:\d+\)/i.test(line) ||
    /DeprecationWarning/i.test(line) ||
    /trace-deprecation/i.test(line);
  const meaningful = errorLines.length
    ? errorLines.filter((line) => !isNoise(line))
    : lines.filter((line) => !isNoise(line));
  if (meaningful.length) return meaningful.slice(-2).join(' ');
  return `exit ${execResult?.status}`;
}

function restartMessage(target) {
  if (target === 'officeace') {
    return '升级完成，请打开连接器 → 我的连接器 → huaweicloud-devkit → 重新连接后使用新版本。';
  }
  return '升级完成，请重启当前会话使新版本生效。';
}

export async function upgradePackage({ target = 'all', version = 'latest' } = {}, options = {}) {
  if (version !== 'latest') {
    return { success: false, error: 'version 参数仅支持 latest。目标版本由插件自动判定。' };
  }
  // The target is interpolated into an npx command spawned with shell:true;
  // reject anything outside the known agent set + 'all' so a crafted value
  // cannot be interpreted as shell operators (review #717).
  const targetStr = String(target);
  if (targetStr !== 'all' && !SUPPORTED_AGENT_TARGETS.includes(targetStr)) {
    return { success: false, error: `不支持的升级目标：${targetStr}` };
  }
  const { doQuery = queryDistTags, spawnFn = defaultSpawn } = options;
  // Tests inject currentVersion explicitly - the repo package.json version changes
  // between prerelease and stable lines, which must not flip the upgrade-tag logic.
  const previousVersion = options.currentVersion || readInstalledVersion();
  let distTags;
  try {
    distTags = await doQuery();
  } catch (error) {
    return {
      success: false,
      error: error?.message || '无法确认最新版本（registry 查询失败）。',
      manual: `npx --yes huaweicloud-devkit@latest update --target ${target}`,
    };
  }
  const targetVersion = determineTarget(previousVersion, distTags ?? {});
  if (distTags === null) {
    return {
      success: false,
      error: '无法确认最新版本（registry 查询失败）。',
      manual: `npx --yes huaweicloud-devkit@latest update --target ${target}`,
    };
  }
  if (!targetVersion) {
    return { success: false, message: '已是最新版本，无需升级。', requiresRestart: false };
  }
  const isNextTarget = Boolean(distTags.next && semverCompare(targetVersion, distTags.next) === 0);
  const tag = isNextTarget ? 'next' : 'latest';
  const command = ['--yes', `huaweicloud-devkit@${tag}`, 'update', '--target', String(target)];
  let execResult;
  try {
    execResult = spawnFn(NPX_BIN, command, { encoding: 'utf8', timeout: 300000, windowsHide: true, shell: true });
  } catch (error) {
    return {
      success: false,
      error: error?.message || '升级命令执行失败。',
      manual: `npx --yes huaweicloud-devkit@${tag} update --target ${target}`,
    };
  }
  if (execResult.status === 0) {
    invalidateUpdateCache();
    return {
      success: true,
      previousVersion,
      installedVersion: targetVersion,
      requiresRestart: true,
      message: restartMessage(target),
    };
  }
  const reason = extractNpmFailureReason(execResult);
  return {
    success: false,
    error: reason,
    manual: `npx --yes huaweicloud-devkit@${tag} update --target ${target}`,
  };
}
